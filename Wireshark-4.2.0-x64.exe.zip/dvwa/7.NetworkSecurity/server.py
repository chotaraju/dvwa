import socket
s = socket.socket()
print ('Socket successfully created')

port = 8080
s.bind(('localhost', port))
print ('socket binded to %s' %(port))
s.listen(5)
print ("socket is listening")
while True:
    c, addr = s.accept()
    print ('Got connection from', addr)
    c.sendall('Thank you for connecting'.encode())
    c.close()
