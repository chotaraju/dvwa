// set PATH=C:\Program Files\Java\jdk1.8.0_202\bin
// javac BookPermission.java
// java BookPermission

import java.io.*;
import java.security.*;
import java.util.*;

class BookPermission extends BasicPermission implements Serializable {
    String bookid = null;
    BitSet pages = new BitSet();

    public BookPermission(String perm) {
        super(perm);
        String[] fields = perm.split(":");
        bookid = fields[0];

        String[] ranges = fields[1].split(",");
        for (String r : ranges) {
            String[] range = r.split("-");
            int start = Integer.parseInt(range[0]);
            int end = range.length > 1 ? Integer.parseInt(range[1]) : start;
            pages.set(start, end + 1);
        }
    }

    public boolean implies(Permission permission) {
        BookPermission bp = (BookPermission) permission;
        if (!bookid.equals(bp.bookid)) {
            System.out.println("Book with Book id:" + bookid + " not found.");
            return false;
        }

        BitSet pgs = (BitSet) bp.pages.clone();
        pgs.or(pages);
        System.out.println("Following Pages are granted Permission:");
        System.out.println(pgs);
        return true;
    }

    public boolean equals(Object obj) {
        return obj instanceof BookPermission &&
               pages.equals(((BookPermission) obj).pages) &&
               bookid.equals(((BookPermission) obj).bookid);
    }

    public static void main(String[] args) {
        Permission p1 = new BookPermission("123:1-3,5,7-10");
        System.out.println("Bookid:Pages (Book stored) -- 123:1-3,5,7-10\n");

        Permission p2 = new BookPermission("123:2");
        System.out.println("Bookid:Pages (Checking) --123:2");
        System.out.println("Access Granted: " + p1.implies(p2) + "\n");

        p2 = new BookPermission("1234:3");
        System.out.println("Bookid:Pages (Checking) --1234:3");
        System.out.println("Access Granted: " + p1.implies(p2) + "\n");

        p2 = new BookPermission("123:3,8-9,20");
        System.out.println("Bookid:Pages (Checking) --123:3,8-9,20");
        System.out.println("Access Granted: " + p1.implies(p2) + "\n");

        p2 = new BookPermission("123:3-5");
        System.out.println("Bookid:Pages (Checking) -- 123:3-5");
        System.out.println("Access Granted: " + p1.implies(p2) + "\n");

        p2 = new BookPermission("123:1-3");
        System.out.println("Bookid:Pages (Checking) -- 123:1-3");
        System.out.println("Access Granted: " + p1.implies(p2) + "\n");
    }
}
