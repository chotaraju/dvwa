# python 3.9.12

# pip install cryptography
# pip install pycryptodome
import socket
from cryptography.fernet import Fernet

# socket
sender_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# receiver's IP address and port
receiver_ip = '127.0.0.1'
receiver_port = 12345

sender_socket.connect((receiver_ip, receiver_port))

# Fernet encryption key
encryption_key = "SPEP7EGhVcmQNQUTBVfCGR14MjBh9ICj1n232KfWdkM="
cipher = Fernet(encryption_key)
print("Availability Achieved: Connection with the receiver is successful.")


while True:
    # encrypting messages
    message = input("You: ")
    encrypted_message = cipher.encrypt(message.encode())
    sender_socket.send(encrypted_message) 
    print("Confidentiality: Data is sent confidentially.")
    print("Integrity: Checking Data integrity is maintained.")
    
sender_socket.close()
