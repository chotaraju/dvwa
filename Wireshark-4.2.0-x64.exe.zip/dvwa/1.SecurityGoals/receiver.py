# python 3.9.12

# pip install cryptography
# pip install pycryptodome
import socket
import cryptography
from cryptography.fernet import Fernet

# socket
receiver_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# receiver's IP address and port
receiver_ip = '0.0.0.0'
receiver_port = 12345

# Bind socket
receiver_socket.bind((receiver_ip, receiver_port))
receiver_socket.listen(1)

print("Waiting for a connection...")
connection, sender_address = receiver_socket.accept()
print("Connected to:", sender_address)

# same encryption key as the sender
encryption_key = b'SPEP7EGhVcmQNQUTBVfCGR14MjBh9ICj1n232KfWdkM='
cipher = Fernet(encryption_key)
print("Availability Achieved: Connection with the sender is successful.")


while True:
    # decrypting messages
    encrypted_data = connection.recv(1024)
    if not encrypted_data:
        break
    try:
        decrypted_message = cipher.decrypt(encrypted_data).decode()
        print("Sender:", decrypted_message)
        print("Confidentiality Achieved: Data is confidential.")
        print("Integrity Achieved: Data integrity is maintained.")
        print("\nSecurity Goals has been implemented successfully\n")

    # Error message for interruption
    except cryptography.fernet.InvalidToken:
        print("Error: Invalid token - message may have been tampered with")

connection.close()
receiver_socket.close()
