import logging

def error_logging():
    # path where error text will be written
    f = open("D:\\errorLogs.txt", "a")

    def error_NameError():
        try:
            print("value of a",a)
        except NameError as namelog:
            logging.error("Error occured: ValueError has occured...")
            print("NameError Logged")
            f.write("1. Name Error\n"+str(namelog))


    def error_ModuleNotFoundError():
        try:
            import abcmodule
        except ModuleNotFoundError as modulelog:
            logging.error("Error occured: ModuleNotFoundError has occured...")
            print("ModuleError Logged")
            f.write("\n\n2. Module Error\n"+str(modulelog))


    def error_IndexError():
        var_list=[3,1,2]
        try:
            print(var_list[5])
        except IndexError as indexlog:
            logging.error("Error occured: IndexError has occured, invalid list indexing...")
            print("IndexError Logged")
            f.write("\n\n3. Index Error\n"+str(indexlog))


    def error_ZeroDivisionError():
        try:
            C=3/0
        except ZeroDivisionError as zerodivlog:
            logging.error("Error occured: ZeroDivisionError has occured...")
            print("ZeroDivisionError Logged")
            f.write("\n\n4. Zero Division Error\n"+str(zerodivlog))


    def error_KeyError():
        var_dict={1:"A word', 2:'Another word"}
        try:
            var_dict[3]
        except KeyError as keylog:
            logging.error("Error occured: KeyError has occured...")
            print("KeyError Logged")
            f.write("\n\n5. Key Error\n"+str(keylog))


    def error_TypeError():
        
        try:
            d=3+'3'
        except TypeError as typelog:
            logging.error("Error occured: TypeError has occured...")
            print("TypeError Logged")
            f.write("\n\n6. Type Error\n"+str(typelog))


    def error_KeyboardInterrupt():
        try:
            while True:
                print(3)
        except KeyboardInterrupt as keyboardinterruptlog:
            logging.error("Error occured: KeyboardInterrupt has occured...")
            print("Keyboardinterrupt Logged")
            f.write("\n\n7. Keyboard Interrupt Error\n"+str(keyboardinterruptlog))


    def critical_error():
        list_size=536870912
        if list_size>100:
            logging.critical("Critical Error occured: Huge resouces requested, cannot provided so much memory for list...")
            print("critical_error Logged")
            f.write("\n\n8. Critical Error")
        else:
            #creating a list with all 0 elements
            var_list=[]
            for i in range(list_size):
                var_list.append(0)
                logging.basicConfig(filename="LogFile.log",level=logging.DEBUG, filemode='w',\
                                    format='Time: %(asctime)s - Name: %(name)s - FilePath: - %(pathname)s \ - FunctionName: %(funcName)s - LevelName:%(levelname)s - Message:%(message)s\ -Line Number: -%(lineno)d - ProcessID:%(process)d - ThreadID: %(thread)d')
                logging.debug("Executing code and logging errors if any...")
                logging.warning("Error expected in multiple functions to be tested")
                logging.info("Program has started...")


    error_NameError()
    error_ModuleNotFoundError()
    error_IndexError()
    error_ZeroDivisionError()
    error_KeyError()
    error_TypeError()
    error_KeyboardInterrupt()
    critical_error()
error_logging()