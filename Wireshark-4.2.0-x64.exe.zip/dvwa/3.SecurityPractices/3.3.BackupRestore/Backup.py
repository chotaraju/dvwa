import os
def backup(path,user,dbname,backuppath,filename):
    cmd = "mysqldump -u " + user + " -p " + dbname + " > " + backuppath + filename
    os.chdir(path)
    os.system(cmd)
    print("Database Backup Successful!")
    print(cmd)
path=input("Enter the Mysql Path:")
user=input("Enter the Username:")
dbname=input("Enter the Database name: ")
backuppath=input("Enter the Backup Path:")
filename=input("Enter the Backup Name:")
backup(path,user,dbname,backuppath,filename)
