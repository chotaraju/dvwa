import os
def backup(path,user,dbname,backuppath,filename):
    cmd = "mysql -u " + user + " -p " + dbname + " < " + backuppath + filename
    os.chdir(path)
    os.system(cmd)
    #print(cmd)
    print("Database Restore Completed!")
path=input("Enter mysql path: ")
user=input("Enter Username: ")
dbname=input("Enter Database Name: ")
backuppath=input("Enter Backup Path: ")
filename=input("Enter Filename:")
backup(path,user,dbname,backuppath,filename)
