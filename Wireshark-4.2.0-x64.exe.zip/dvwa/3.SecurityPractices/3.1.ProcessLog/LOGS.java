// set PATH=C:\Program Files\Java\jdk1.8.0_202\bin
// javac LOGS.java
// java LOGS


import java.io.FileWriter;
public class LOGS
{
	public static void main(String[] args) 
	{
		try
		{
			// create a CIS folder in C dive
			String cmd = "WMIC /OUTPUT:C:\\CIS\\LIST.HTML PROCESS get name,processid,creationdate /format:hform";
			FileWriter fos = new FileWriter("C:\\CIS\\mycmd.bat");
			System.out.println("File created");
			fos.write(cmd);
			fos.close();
			Runtime rt = Runtime.getRuntime();
			rt.exec("cmd.exe /c start C:\\CIS\\mycmd.bat");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}