#For a given network find the following:
#(i)  Length of the shortest path from a given node to another node;
#(ii) the density of the graph;

install.packages("igraph")
library(igraph)

# Define adjacency matrix
matt <- as.matrix(read.table(text = 
"node R S T U
      R 7 5 0 0
      S 7 0 0 2
      T 0 6 0 0
      U 4 0 1 0",header=T))


# Extract node names
nms <- matt[,1 ]
matt <- matt[,-1]
colnames(matt)<- rownames(matt)<-nms
matt[is.na(matt)]<-0


# Create graph from adjacency matrix
g<-graph.adjacency(matt,weighted = TRUE)
plot(g)


# (i) Length of the shortest path from a given node to another node
# Shortest paths matrix
s.paths<-shortest.paths(g, algorithm= "dijkstra")
print(s.paths)


# Length of the shortest path from node R to node S
shortest.paths(g, v="R", to="S")

# graph with edge weights
plot(g, edge.label=E(g) $weight)



# (ii) the density of the graph;
library(igraph)

# Calculate the density of the graph
dg <- graph.formula(1-+2, 1-+3, 2++3)
plot(dg) #directed graph

# Density of the graph (including loops)
graph.density(dg, loops=TRUE)

# Density of the graph (excluding loops)
graph.density(simplify(dg), loops=FALSE)
