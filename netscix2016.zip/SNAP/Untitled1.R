#Write a program to compute the following for a given a network: 
#(i) number of edges (ii) number of nodes (iii) degree of node (iv) node with lowest degree 
#(v) the adjacency list (vi) matrix of the graph 


install.packages("igraph")

library('igraph')

# Create a graph
g <- graph.formula(1-2, 1-3, 2-3, 2-4, 3-5, 4-5, 4-6,4-7, 5-6, 6-7)


#Name of Edges & Nodes
V(g) 
E(g)


#Plotting of graph
plot(g)


# Directed graph example
dg <- graph.formula(1-+2, 1-+3, 2++3)
plot(dg)


# Directed graph example
dg1 <- graph.formula(Sam-+Mary, Sam-+Tom, Mary++Tom)
plot(dg1)  


#Number of vertices/node: 
vcount(g)


#Number of edges/dyad/ties: 
ecount(g)


# Degree of vertices (total)
degree(g)

# Degree of vertices (in-degree)
degree(dg, mode="in")

# Degree of vertices (out-degree)
degree(dg, mode="out")

#Node with lowest degree 
V(dg)$name[degree(dg)==min(degree(dg))]

#Node with highest degree 
V(dg)$name[degree(dg)==max(degree(dg))]


# Neighbors of a vertex
neighbors(g,5) 
neighbors(g,2)


# Get adjacency list and adjacency matrix
get.adjlist(dg)
get.adjacency(g)