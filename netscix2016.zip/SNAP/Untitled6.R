#Write a program to exhibit
# i) Structural equivalence, 
# ii) Automorphic equivalence, 
# iii) Regular equivalence from a network.

install.packages('sna')
library('sna')

# Read the edge file
links2 <- read.csv("netscix2016/Dataset2-Media-User-Example-EDGES.csv", header = TRUE)

# Display the first few rows of the edge file
head(links2)

# Perform equivalent clustering on the edge data
eq <- equiv.clust(dat = links2)

# Read the edge file with row names
links2 <- read.csv("netscix2016/Dataset2-Media-User-Example-EDGES.csv", header = TRUE, row.names = 1)

# Display the first few rows of the edge file
head(links2)

# Perform equivalent clustering on the node data
eq <- equiv.clust(dat = links2)

# Plot the equivalent clustering result
plot(eq)

# Calculate the spatial Euclidean distance
g.se <- sedist(links2)

# Plot the multidimensional scaling (MDS) of the spatial Euclidean distance
plot(cmdscale(as.dist(g.se)))

# Perform blockmodeling using equivalent clustering result and a specified height (h)
b <- blockmodel(links2, eq, h = 10)

# Plot the blockmodel result
plot(b)