# To Calculate Hamming Distance

#Calculate Hamming distance
install.packages("e1071")
library(e1071)

x <- c(0, 0, 0, 0)
y <- c(0, 1, 0, 1)
z <- c(1, 0, 1, 1)
w <- c(0, 1, 1, 1)


hamming.distance(x, y)

hamming.distance(y,z)

hamming.distance(y,w)

hamming.distance(z,w)

hamming.distance(x, w)

hamming.distance(x, z)

