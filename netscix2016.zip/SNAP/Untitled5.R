#Write a program to distinguish between: -
#  i) a network as a sociogram (basically a “network graph”)
#  ii) a network as a matrix iii) a network as an edge list.  
#using distinct networks for each representation.

install.packages("igraph")
library(igraph)

# Create a network as a sociogram (network graph)
ng <- graph.formula(Andy++Garth, Garth-+Bill, Bill+Elena, Elena++Frank, Carol+Andy, Carol-+Elena, Carol++Dan, Carol++Bill, Dan++Andy, Dan++Bill)
plot(ng)  # Plot the sociogram

# Create a network as a matrix
# Represent the network as an adjacency matrix
get.adjacency(ng)

# Create a network as an edge list
# Retrieve the edge list of the network
E(ng)

# Alternatively, if you want to get the edge list with directionality (in and out edges)
get.adjedgelist(ng, mode = "in")
