-- Oracle Spatial Mapping and To perform Spatial Data.

Create a spatial database based on real world location:
The map is based on the state of Tamil Nadu.
It contains the major cities, rivers, lakes and sanctuaries in the state of Tamil Nadu.

Graph:

-- Insert Tamil Nadu state boundary
INSERT INTO States
VALUES (
    'Tamil Nadu',
    MDSYS.SDO_GEOMETRY(
        2003,
        NULL,
        NULL,
        MDSYS.SDO_ELEM_INFO_ARRAY(1, 1003, 1),
        MDSYS.SDO_ORDINATE_ARRAY(
            76.23, 13.00,  -- Northwest point
            77.54, 13.00,  -- Northeast point
            80.27, 11.41,  -- Chennai
            79.84, 11.93,  -- Pondicherry
            79.15, 10.79,  -- Thanjavur
            78.12, 9.93,   -- Madurai
            77.73, 8.73,   -- Tirunelveli
            76.95, 8.07,   -- Southern tip
            76.23, 13.00   -- Back to start
        )
    )
);

-- Insert major cities
INSERT INTO City VALUES (
    'Chennai',
    MDSYS.SDO_GEOMETRY(
        2001,
        NULL,
        MDSYS.SDO_POINT_TYPE(80.27, 13.08, NULL),
        NULL,
        NULL
    ),
    MDSYS.SDO_GEOMETRY(
        2003,
        NULL,
        NULL,
        MDSYS.SDO_ELEM_INFO_ARRAY(1, 1003, 3),
        MDSYS.SDO_ORDINATE_ARRAY(80.17, 13.18, 80.37, 12.98)
    )
);

INSERT INTO City VALUES (
    'Madurai',
    MDSYS.SDO_GEOMETRY(
        2001,
        NULL,
        MDSYS.SDO_POINT_TYPE(78.12, 9.93, NULL),
        NULL,
        NULL
    ),
    MDSYS.SDO_GEOMETRY(
        2003,
        NULL,
        NULL,
        MDSYS.SDO_ELEM_INFO_ARRAY(1, 1003, 3),
        MDSYS.SDO_ORDINATE_ARRAY(78.02, 10.03, 78.22, 9.83)
    )
);

INSERT INTO City VALUES (
    'Coimbatore',
    MDSYS.SDO_GEOMETRY(
        2001,
        NULL,
        MDSYS.SDO_POINT_TYPE(76.96, 11.00, NULL),
        NULL,
        NULL
    ),
    MDSYS.SDO_GEOMETRY(
        2003,
        NULL,
        NULL,
        MDSYS.SDO_ELEM_INFO_ARRAY(1, 1003, 3),
        MDSYS.SDO_ORDINATE_ARRAY(76.86, 11.10, 77.06, 10.90)
    )
);

-- Insert major rivers
INSERT INTO River VALUES (
    'Cauvery',
    MDSYS.SDO_GEOMETRY(
        2002,
        NULL,
        NULL,
        MDSYS.SDO_ELEM_INFO_ARRAY(1, 2, 1),
        MDSYS.SDO_ORDINATE_ARRAY(
            77.16, 11.68,  -- Entry point
            78.48, 11.37,  -- Erode
            79.15, 10.79,  -- Thanjavur
            79.49, 10.83   -- Delta point
        )
    )
);

INSERT INTO River VALUES (
    'Vaigai',
    MDSYS.SDO_GEOMETRY(
        2002,
        NULL,
        NULL,
        MDSYS.SDO_ELEM_INFO_ARRAY(1, 2, 1),
        MDSYS.SDO_ORDINATE_ARRAY(
            77.49, 10.18,  -- Origin
            78.12, 9.93,   -- Madurai
            79.38, 9.28    -- Gulf of Mannar
        )
    )
);

-- Create table for Lakes and Sanctuaries
CREATE TABLE WaterBodies (
    name VARCHAR2(32),
    type VARCHAR2(32),
    geometry MDSYS.SDO_GEOMETRY
);

-- Insert metadata for WaterBodies
INSERT INTO USER_SDO_GEOM_METADATA
VALUES (
    'WaterBodies',
    'geometry',
    MDSYS.SDO_DIM_ARRAY(
        MDSYS.SDO_DIM_ELEMENT('X', 0, 2000, 0.005),
        MDSYS.SDO_DIM_ELEMENT('Y', 0, 2000, 0.005)
    ),
    NULL
);

-- Create spatial index for WaterBodies
CREATE INDEX waterbodies_spatial_idx
    ON WaterBodies(geometry)
    INDEXTYPE IS MDSYS.SPATIAL_INDEX;

-- Insert lakes and sanctuaries
INSERT INTO WaterBodies VALUES (
    'Pulicat Lake',
    'Lake',
    MDSYS.SDO_GEOMETRY(
        2003,
        NULL,
        NULL,
        MDSYS.SDO_ELEM_INFO_ARRAY(1, 1003, 1),
        MDSYS.SDO_ORDINATE_ARRAY(
            80.15, 13.64,
            80.35, 13.64,
            80.35, 13.33,
            80.15, 13.33,
            80.15, 13.64
        )
    )
);

INSERT INTO WaterBodies VALUES (
    'Mudumalai',
    'Sanctuary',
    MDSYS.SDO_GEOMETRY(
        2003,
        NULL,
        NULL,
        MDSYS.SDO_ELEM_INFO_ARRAY(1, 1003, 1),
        MDSYS.SDO_ORDINATE_ARRAY(
            76.32, 11.67,
            76.64, 11.67,
            76.64, 11.52,
            76.32, 11.52,
            76.32, 11.67
        )
    )
);

-- Example queries specific to Tamil Nadu

-- 0. Find all cities within 100km of Chennai

-- 1. Find rivers intersecting with Madurai city region
SELECT r.name
FROM River r, City c
WHERE c.name = 'Madurai'
AND SDO_GEOM.RELATE(r.route, 'ANYINTERACT', c.region, 0.005) = 'TRUE';

-- 2. Calculate the total length of Cauvery river in Tamil Nadu
SELECT SDO_GEOM.SDO_LENGTH(route, 0.005) as length_km
FROM River
WHERE name = 'Cauvery';

-- 3. Find all sanctuaries near Coimbatore (within 150km)
SELECT wb.name
FROM WaterBodies wb, City c
WHERE c.name = 'Coimbatore'
AND wb.type = 'Sanctuary'
AND SDO_GEOM.SDO_DISTANCE(wb.geometry, c.center, 0.005) <= 150;

-- 4. DISJOINT Query
-- Find cities that are disjoint from Cauvery river
SELECT c.name AS cities_disjoint_from_cauvery
FROM City c, River r, user_sdo_geom_metadata m, user_sdo_geom_metadata m1
WHERE r.name = 'Cauvery'
AND sdo_geom.RELATE(c.region, m.diminfo, 'DISJOINT', r.route, m1.diminfo) = 'DISJOINT'
AND m.table_name = 'CITY'
AND m1.table_name = 'RIVER'
AND m.column_name = 'REGION'
AND m1.column_name = 'ROUTE';


