-- To create and manipulate a spatial database using Oracle Spatial features to model states, cities, and rivers, and perform spatial queries for geometric relationships, intersections, distances, and area calculations.

-- Question:
Create a spatial database based on the following information
Create three relations
State (region, name)
City (center,region,name)
Rivers (name, route)
Note: Scale 1 Unit = 100 km

Given:
1.	State ‘st1’ which extends from (10,10),(60,60) ,(50,10) ,(10,40)
2.	State ‘st2’ which has two opposite corners situated at (100,50) & (150,20)
3.	City ‘C1’ with center at (15,35) region is circular with largest road of 10 
4.	 City ‘C2’ with center at (22,35) region is circular with the largest road of 4.
5.	City ‘C3’ with center as (55,40) region is point
6.	City ‘C4’ with center (48,33) which is rectangular with corner situated at (40,30) & (55,15)
7.	City ‘C5’ with center (120,35) extending from (120,40) to (130,30)
8.	River ‘r1’  with route extending from (15,25) to (52,58)
9.	River ‘r2’  with route extending from (10,30) to (60,45)
10.	River ‘r3’  with route extending from (55,30) to (110,30)

Queries:
1.	Locate all cities in state ‘st1’
2.	 Locate all cities in state ‘st2’
3.	 Locate all cities not more than 10 km from ‘c3’
4.	 Locate the cities touching city ‘c2’
5.	 Locate city within 5km from ‘r2’
6.	 Locate cities intersected by river ‘r2’
7.	 Find cities intersected by ‘r3’
8.	Find the population in every city of state ‘st1’ if the population per sq. km. is 6.
9.	Find distance between two states.

Graphical Representation:


-- Program code:
create table spatitab
(mkt_id number primary key, name varchar2(32),
shape MDSYS.SDO_GEOMETRY);

-- Program code:
desc spatitab;

-- Program code:
-- #inserting records into the table insert into spatitab VALUES
(
1,
'abc', MDSYS.SDO_GEOMETRY (
2003, NULL, NULL,
MDSYS.SDO_ELEM_INFO_ARRAY(1,1003,3), MDSYS.SDO_ORDINATE_ARRAY(1,1, 5,7)
));

-- Program code:
insert into spatitab values (
2,
'pqr', MDSYS.SDO_GEOMETRY (
2003, NULL, NULL,
MDSYS.SDO_ELEM_INFO_ARRAY(1,1003,1), MDSYS.SDO_ORDINATE_ARRAY(5,1, 8,1, 8,6, 5,7, 5,1)
));

-- Program code:
insert into spatitab values (
3,
'mno', MDSYS.SDO_GEOMETRY (
2003, NULL, NULL,
MDSYS.SDO_ELEM_INFO_ARRAY(1,1003,1), MDSYS.SDO_ORDINATE_ARRAY(3,3, 6,3, 6,5, 4,5, 3,3)
));

-- Program code:
insert into spatitab values (
4,
'xyz', MDSYS.SDO_GEOMETRY (
2003, NULL, NULL,
MDSYS.SDO_ELEM_INFO_ARRAY(1,1003,4), MDSYS.SDO_ORDINATE_ARRAY(8,7, 10,9, 8,11)
));
 
-- Program code:
-- #creating a metadata
insert into USER_SDO_GEOM_METADATA values (
'spatitab', 'shape',
MDSYS.SDO_DIM_ARRAY (
MDSYS.SDO_DIM_ELEMENT('X', 0, 20, 0.005),
MDSYS.SDO_DIM_ELEMENT('Y', 0, 20, 0.005)
),
NULL);

-- Program code:
-- #Creating a spatial index i.e. table-column combination; here, spatitab and SHAPE.
create index spatitab_spatial_idx on spatitab(shape)
indextype is MDSYS.SPATIAL_INDEX
 
-- Query 1: Find the topological intersection of two geometries.
select SDO_GEOM.SDO_INTERSECTION(c_a.shape, c_c.shape,
0.005)
from spatitab c_a, spatitab c_c
where c_a.name = 'abc' and c_c.name = 'mno';

-- Query 2: Find whether two geometric figures are equivalent to each other. 
select SDO_GEOM.RELATE(c_b.shape, 'anyinteract',
c_d.shape, 0.005)
from spatitab c_b, spatitab c_d
where c_b.name = 'pqr' and c_d.name = 'xyz'
 
-- Program code:
select SDO_GEOM.RELATE(c_b.shape, 'anyinteract', c_a.shape,
0.005)
from spatitab c_b, spatitab c_a
where c_b.name = 'pqr' and c_a.name = 'abc';
Output:

-- Query 3: Find the areas of all different locations.
select name, SDO_GEOM.SDO_AREA(shape, 0.005) from spatitab

-- Query 4:Find the area of only one location.
select c.name, SDO_GEOM.SDO_AREA(c.shape, 0.005) from spatitab c
where c.name = 'abc';

-- Query 5: Find the distance between two geometries.
select SDO_GEOM.SDO_DISTANCE(c_b.shape, c_d.shape, 0.005)
from spatitab c_b, spatitab c_d
where c_b.name = 'pqr' and c_d.name = 'xyz';