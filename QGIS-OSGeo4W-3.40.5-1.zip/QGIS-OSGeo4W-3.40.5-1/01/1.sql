-- A)	Relational Database schema    

-- Table Creation
CREATE TABLE Product (
    ID VARCHAR2(10),
    CUST XMLTYPE
);

-- Inserting 3 Rows with multiple orders and items
INSERT INTO Product VALUES (
    1, XMLTYPE('
    <CUSTOMER>
        <CID>C001</CID>
        <NAME>Ram</NAME>
        <CITY>Mumbai</CITY>
        <ORDER>
            <OID>O001</OID>
            <ODATE>25/01/2006</ODATE>
            <ORDER_ITEM>
                <NAME>Mouse</NAME>
                <QTY>25</QTY>
            </ORDER_ITEM>
            <ORDER_ITEM>
                <NAME>Keyboard</NAME>
                <QTY>10</QTY>
            </ORDER_ITEM>
        </ORDER>
        <ORDER>
            <OID>O002</OID>
            <ODATE>31/01/2006</ODATE>
            <ORDER_ITEM>
                <NAME>PenDrive</NAME>
                <QTY>2</QTY>
            </ORDER_ITEM>
            <ORDER_ITEM>
                <NAME>Modem</NAME>
                <QTY>5</QTY>
            </ORDER_ITEM>
        </ORDER>
    </CUSTOMER>')
);

INSERT INTO Product VALUES (
    2, XMLTYPE('
    <CUSTOMER>
        <CID>C002</CID>
        <NAME>Shyam</NAME>
        <CITY>Pune</CITY>
        <ORDER>
            <OID>O003</OID>
            <ODATE>02/02/2006</ODATE>
            <ORDER_ITEM>
                <NAME>Monitor</NAME>
                <QTY>7</QTY>
            </ORDER_ITEM>
            <ORDER_ITEM>
                <NAME>CPU</NAME>
                <QTY>15</QTY>
            </ORDER_ITEM>
        </ORDER>
    </CUSTOMER>')
);

INSERT INTO Product VALUES (
    3, XMLTYPE('
    <CUSTOMER>
        <CID>C003</CID>
        <NAME>Sita</NAME>
        <CITY>Delhi</CITY>
        <ORDER>
            <OID>O004</OID>
            <ODATE>05/02/2006</ODATE>
            <ORDER_ITEM>
                <NAME>Printer</NAME>
                <QTY>3</QTY>
            </ORDER_ITEM>
            <ORDER_ITEM>
                <NAME>Scanner</NAME>
                <QTY>2</QTY>
            </ORDER_ITEM>
        </ORDER>
    </CUSTOMER>')
);

-- Extract XML fragment for order items for order O001
SELECT p.CUST.extract('/CUSTOMER/ORDER[OID="O001"]/ORDER_ITEM').getStringVal() AS "Order_Items"
FROM Product p;

-- Extracting XML fragment for orders of customer with customer_id = 'C001'
SELECT p.CUST.extract('/CUSTOMER').getStringVal() 
FROM Product p 
WHERE p.CUST.extract('//CUSTOMER/CID/text()').getStringVal() = 'C001';

-- Inserting a row with id=5 and no orders for the customer
INSERT INTO Product VALUES (5, NULL);

-- Inserting a row with no order date for an order
INSERT INTO Product VALUES (
    4, XMLTYPE('
    <CUSTOMER>
        <CID>C004</CID>
        <NAME>Laloo</NAME>
        <CITY>Patna</CITY>
        <ORDER>
            <OID>O005</OID>
            <ODATE></ODATE>
            <ORDER_ITEM><NAME>Fodder</NAME><QTY>50</QTY></ORDER_ITEM>
        </ORDER>
    </CUSTOMER>')
);

-- Select rows with NULL in the customer’s order node
SELECT ID 
FROM Product 
WHERE CUST IS NULL;

-- Selecting rows with no order date
SELECT ID, p.CUST.extract('/CUSTOMER/ORDER/OID/text()').getStringVal() AS "Order_ID" 
FROM Product p 
WHERE p.CUST.extract('/CUSTOMER/ORDER/ODATE/text()').getStringVal() IS NULL;

-- Displaying the date on which order O001 was placed
SELECT p.CUST.extract('/CUSTOMER/ORDER[OID="O001"]/ODATE/text()').getStringVal() AS "Order_Date"
FROM Product p;

-- Display the quantity of product Mouse in order O001 as numeric
SELECT p.CUST.extract('/CUSTOMER/ORDER[OID="O001"]/ORDER_ITEM[NAME="Mouse"]/QTY/text()').getNumberVal() AS "Quantity"
FROM Product p;

-- Display the quantity of product Mouse in order O001 without using extract() function
SELECT p.CUST.extractValue('/CUSTOMER/ORDER[OID="O001"]/ORDER_ITEM[NAME="Mouse"]/QTY') AS "Quantity"
FROM Product p;

-- OR

SELECT x.Quantity
FROM Product p,
XMLTABLE('/CUSTOMER/ORDER[OID="O001"]/ORDER_ITEM[NAME="Mouse"]' 
PASSING p.CUST
COLUMNS Quantity NUMBER PATH 'QTY'
) x;

-- Display items ordered in O002 using ExtractValue() and explain observations
SELECT p.CUST.extractValue('/CUSTOMER/ORDER[OID="O002"]/ORDER_ITEM') AS "Order_Items"
FROM Product p;

-- OR

SELECT x.ItemName, x.Quantity
FROM Product p,
XMLTABLE('/CUSTOMER/ORDER[OID="O002"]/ORDER_ITEM' 
PASSING p.CUST
COLUMNS 
ItemName VARCHAR(100) PATH 'NAME',
Quantity NUMBER PATH 'QTY'
) x;


-- Extract dates of orders where they exist
SELECT p.CUST.extract('/CUSTOMER/ORDER/ODATE/text()').getStringVal() AS "Order_Date"
FROM Product p 
WHERE p.CUST.extract('/CUSTOMER/ORDER/ODATE/text()') IS NOT NULL;