-- B)  XML Databases 

-- Table Creation
create table employee(dept_id number(5), employee_spec xmltype)

-- Inserting Records Into Table Employee
insert into employee 
    values(001,
    xmltype('<emp id="1">
    <name>viraj</name> 
    <email>viraj@gmail.com</email> 
    <acc_no>1234</acc_no> 
    <mgremail>abc@yahoo.com</mgremail> 
    <doj>23-jul-2005</doj>  
    </emp>'))
insert into employee 
    values(002,
    xmltype('<emp id="2">
    <name>Deepak</name> 
    <email>depak@gmail.com</email> 
    <acc_no>45554</acc_no> 
    <mgremail>abc@yahoo.com</mgremail> 
    <doj>23-jul-2005</doj>  
    </emp>'))
insert into employee 
    values(003,
    xmltype('<emp id="3">
    <name>Shubham Singh</name> 
    <email>shubham@gmail.com</email> 
    <acc_no>3535734</acc_no> 
    <mgremail>abc@yahoo.com</mgremail> 
    <doj>23-jul-2005</doj>  
    </emp>'))
insert into employee 
    values(004,
    xmltype('<emp id="4">
    <name>Atharva</name> 
    <email>atharva@gmail.com</email> 
    <acc_no>125234</acc_no> 
    <mgremail>abc@yahoo.com</mgremail> 
    <doj>23-jul-2005</doj>  
    </emp>'))


-- Query 1: Retrieve the names of employees.  
select e.employee_spec.extract('emp/name/text()').getStringVal() 
    "Employee_Name"  
    from employee e  
Output:
 
-- Query 2: Retrieve the acc_no. of employees.
select e.employee_spec.extract('emp/acc_no/text()').getStringVal() 
    "Employee Account-No"  
    from employee e 
Output:

-- Query 3: Retrieve the names, acc_no, email of employees.  
select e.employee_spec.extract('emp/name/text()').getStringVal(),
    e.employee_spec.extract('emp/acc_no/text()').getStringVal(), 
    e.employee_spec.extract('emp/email/text()').getStringVal()  
    from employee e  
Output:
 
-- Query 4: Update the 3rd record from the table and display the name of an employee. 
update employee e set employee_spec = xmltype  
    ('<emp id="4">  
    <name>Pratham</name>  
    </emp>')  
    where e.employee_spec.extract('//acc_no/text()').getStringVal()='125234'  
Output:
 

-- Query 5: Delete the 4ᵗʰ record from the table.
delete from employee e  
    where e.employee_spec.extract('//name/text()').getStringVal()='Pratham'