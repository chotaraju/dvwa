-- B)  XML Databases 

-- Table Creation
create table candixml  (id varchar2(10),  resume xmltype);  

-- Inserting XML Data 
insert into candixml values('a001',
    xmltype(  
    '<emp id="1">  
    <name>jigi</name>  
    <address>virar</address>  
    <skill>  
    <compskill>  
    <lang>java</lang>  
    <os>linux</os>  
    </compskill>  
    </skill>  
    <expr>  
    <programer>3</programer>  
    <proj_mgr>1</proj_mgr>  
    </expr>  
    <objective>to become a good programer</objective>  
    </emp>'))  
insert into candixml values('a002',
    xmltype(  
    '<emp id="2">  
    <name>viraj</name>  
    <address>dombivli</address>  
    <skill>  
    <compskill>  
    <lang>java</lang>  
    <os>linux</os>  
    </compskill>  
    </skill>  
    <expr>  
    <programer>4</programer>  
    <proj_mgr>2</proj_mgr>  
    </expr>  
    <objective>to become a good programer</objective>  
    </emp>'))  
insert into candixml values('a003',
    xmltype(  
    '<emp id="3">  
    <name>shubham</name>  
    <address>chembur</address>  
    <skill>  
    <compskill>  
    <lang>java</lang>  
    <os>linux</os>  
    </compskill>  
    </skill>  
    <expr>  
    <programer>5</programer>  
    <proj_mgr>5</proj_mgr>  
    </expr>  
    <objective>to become a good programer</objective>  
    </emp>')) 

-- Selecting the employee wi/th specific conditions
select e.resume.getClobval() "employee spec"  
    from candixml e where 
    e.resume.extract('//skill/compskill/lang/text()').getStringVal()='java'   
    and e.resume.extract('//expr/programer/text()').getStringVal()='5'   

 
-- Extracting an employee name based on Experience condition
select e.resume.extract('emp/name/text()').getStringVal() "EName" 
    from candixml e  
    where e.resume.existsNode('/emp/expr[proj_mgr>="1"]') = 1   
 
-- Selecting the Multiple Elements from XML
select  
    e.resume.extract('emp/name/text()').getStringVal() "EName",  
    e.resume.extract('emp/skill/compskill/lang/text()').getStringVal() "ESkillLang",  
    e.resume.extract('emp/skill/compskill/os/text()').getStringVal() "ESkillNw"   
    from candixml e  
 
-- Deleting Rows based on XML content
delete from candixml e  
    where e.resume.extract('//address/text()').getStringVal()   ='virar'  

-- Updating XML Data
update candixml e  
    set resume=XMLType('<emp><name>Shubham</name></emp>')  
    where id='a003'