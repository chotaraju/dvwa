-- Design a XML Schema for Payroll and Design 5 Queries (Case Study)

-- Payroll (Schema hierarchy)
-- Employee
-- |--- EmpID
-- |--- EmpName
-- |--- Department
-- |--- Designation
-- |--- Salary

-- Table Creation
CREATE TABLE payroll (dep_id number(5), payroll_data XMLTYPE);

-- Data Insertion
INSERT INTO payroll VALUES (001, XMLTYPE('
<Payroll>
<Employee>
<empID>E001</empID>
<EmpName>Shubham Singh</EmpName>
<Department>IT</Department>
<Designation>Software Engineer</Designation>
<Salary>45000</Salary>
</Employee>
<Employee>
<empID>E002</empID>
<EmpName>Durgesh Rathore</EmpName>
<Department>IT</Department>
<Designation>Recruiter</Designation>
<Salary>30000</Salary>
</Employee>
<Employee>
<empID>E003</empID>
<EmpName>Viraj Gosavi</EmpName>
<Department>IT</Department >
<Designation>System Analyst</Designation>
<Salary>40000</Salary>
</Employee>
</Payroll>')
);

-- List All Employees in the Payroll
Select p.payroll_data.extract('/Payroll/Employee/EmpName/text()').getStringVal() AS "Employee_Name" FROM payroll p;
 
-- List All Employees in the IT Department
Select p.payroll_data.extract('/Payroll/Employee[Department= "IT"]/empID/text()').getStringVal() AS "Employee_ID", p.payroll_data.extract('/Payroll/Employee[Department="IT"]/EmpName/text()').getStringVal() AS "Employee Name",
p.payroll_data.extract('/Payroll/Employee[Department="IT"]/Designation/text()').getStringVal() AS "Designation", p.payroll_data.extract('/Payroll/Employee[Department="IT"]/Salary/text()').getStringval() AS "Salary" FROM payroll p;

-- List All Employees whose salary is greater and equal to 40,000
Select p.payroll_data.extract('/Payroll/Employee[Salary>=40000]/empID/text()').getStringVal() AS "Employee_ID", p.payroll_data.extract('/Payroll/Employee[Salary>=40000]/EmpName/text()').getStringVal() AS "Employee_Name" FROM payroll p;
 
-- Retrieve Employees with Designation "System Analyst"
SELECT 
    p.payroll_data.EXTRACT('/Payroll/Employee[Designation="System Analyst"]/empID/text()').getStringVal() AS "Employee_ID",
    p.payroll_data.EXTRACT('/Payroll/Employee[Designation="System Analyst"]/EmpName/text()').getStringVal() AS "Employee_Name"
FROM 
    payroll p;

-- Retrieve Total Salary of Employees in the IT Department
SELECT 
    SUM(
        TO_NUMBER(
            p.payroll_data.EXTRACT('/Payroll/Employee[Department="IT"]/Salary/text()').getStringVal()
        )
    ) AS "Total_Salary"
FROM 
    payroll p;