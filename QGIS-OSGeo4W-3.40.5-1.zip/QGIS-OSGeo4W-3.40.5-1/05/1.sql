-- Real World Case Studies based on Redis (NoSQL) type of database 


-- 1.	Open redis setup and click next
-- 2.	Accept the license agreement
-- 3.	Destination folder
-- 4.	Show the port no (6379) where redis run.
-- 5.	Shows memory limit.
-- 6.	Ready for installation
 
-- After Installation, Open redis-cli.exe file from above path (where redis is installed)
-- C:\Program Files\Redis   and open redis-cli

-- GET ALL KEYS VALUES:
-- 1.	Most object use a key:
-- Data will be stored in a simple key/value pair. This is best shown through the redis-cli(command line interface) using GET and SET commands.
 Ping
Set person dsr
Get person
Set person sdsr
Get person


-- 2.	Using Namespaces:
-- We cannot reuse the same title and author keys or we'll overwrite the existing data. Instead, we can use namespace syntax by using a ':' separator and giving each title or author entry a unique numeric key.
 Set language1: “Angular JS”
Get language1
Set language:1 “Angular JS”
Get language1
set developer:1 "Guido van Rossum"
set language:2 "Java"
set developer:2 "Moon Microsystems"
get language:1
get developer:2

-- 3.	Retrieving all existing keys:
-- To get a list of all current keys that exist, simply use the KEYS command.
 KEYS *
-- To search for specific words or phrases within the key,or the exact match as well. Then the syntax will be
-- syntax - KEYS *language_name*
 KEYS *developer*
KEYS *language*



-- Programming Commands with Output:
-- 1)	DEL command: Number of keys that were removed.
	syntax : del key_name  del language:1
 
-- 2)	DUMP and EXISTS command:  Serialized value (String)
	syntax: DUMP key_name
	dump developer:1
	exists year

-- This command is used to check whether the key exists in Redis or not
1, if the key exists.
0, if the key does not exist.
	syntax: EXISTS key_name
 
-- 3)	EXPIRE command: Redis Expire command is used to set the expiry of a key. After the expiry time, the key will not be available in Redis.
	Return Value || Integer value 1 or 0
	1, if a timeout is set for the key.
	0, if the key does not exist or timeout could not be set.
	syntax- EXPIRE key_name time_in_seconds
    expire developer:2 30
    exists developer:2  

-- TYPE command:- It Returns the data type of the value stored in the key.
	type developer:1


-- 4)	TYPE command: It Returns the data type of the value stored in the key.
	syntax- TYPE key_name
 

-- Redis execution:

-- 1)	Create table and Insert value : For creating any table in redis use SET command
syntax- HMSET table_name column 1 value.... column n 
query- HMSET language name "Angular JS" developer " Durgesh Singh" year 2010 rank 19
	 
-- 2)	Get particular column value from table: To get value from table use HGET command
syntax- HGET table_name column_name
query- HGET language name
 
-- 3)	Display all the columns of the table: Use HKEYS command to display all the columns of the table
	syntax- HKEYS table_name
	query- HKEYS language
 
-- 4)	Display exact number of columns of the table: To display exact number of columns of the table use HLEN command
	syntax- HLEN table_name
	query- HLEN language
	 
-- 5)	Display all columns values : To display all columns values of the table use HVALS command
syntax - HVALS table_name
	query - HVALS language
	 

-- 6)	Delete one or more fields: For deleting field in table use HDEL command
		If field is exits it return 1 otherwise 0
	syntax - HDEL table_name field
	query - HDEL language name
	 
