-- Neo4J 1

-- Open the database in neo4j browser and add nodes
CREATE (d:student{name:"Person1", yob:2002, place:"Mumbai"})
CREATE (d:student{name:" Person2", yob:2006, place:"Pune"})
CREATE (d:student{name:" Person3", yob:2006, place:"Satara"})
CREATE (d:student{name:" Person4", yob:2006, place:"Banglore"})

-- Now create relationships
MATCH(d:student {name: "Person1"})
CREATE(c:college {name: "Sies"})
CREATE (d)-[r:student_of]->(c)
RETURN d,c

MATCH (n) RETURN n LIMIT 25
-- to show all 

-- OR

MATCH (n:student) RETURN n LIMIT 25- to show students

MATCH (n:college) RETURN n LIMIT 25- to show college

-- To return count- 
MATCH (d:student)
RETURN COUNT(d)


-- Case Study: Create nodes- customers, accounts and transactions and create relationship between a customer with account, and account with transaction.
-- Nodes:
CREATE (d:customers{name:"Alice", id: 101, city:"New york"})
CREATE (d:customers{name:"BOB", id: 102, city:"Mumbai"})
CREATE (d:customers{name:"Alice", id: 101, city:"New york"})
CREATE (a:accounts{accno:12345, balance: 5000})
CREATE (a:accounts{accno:67890, balance: 4500})
CREATE (t:transactions{tid:11, amount: 1000, date: "2023-04-12"})
CREATE (t:transactions{tid:12, amount: 2000, date: "2023-05-24"})

-- Relationships
MATCH(x:customers{name:"Alice"}), (y:accounts{accno:12345})
CREATE (x)-[:OWNS]->(y);
MATCH(y:accounts{accno:12345}), (z:transactions{tid:11})
CREATE (y)-[:TRANSACTION]->(z);

MATCH (n) RETURN n LIMIT 25

-- Merge
MERGE (FraudulentActivity:Alert {alertType: "High-Value Transactions"});
MATCH (n:ALERT) RETURN n LIMIT 25

-- Set 
MATCH (t:transactions{tid: 12}) SET t.flagged=true;

-- Where 
MATCH (t:transactions) WHERE t.flagged=true RETURN t;

-- Count
MATCH (a:accounts{accno:12345})-[:TRANSACTION]->(t:transactions) RETURN COUNT(t) AS transactionCount;

-- Order By
MATCH (t:transactions) RETURN t.tid, t.amount ORDER BY t.amount DESC;

-- Delete
MATCH (t:transactions{tid: 12}) DETACH DELETE t;
