-- spatial database using Oracle Spatial, enabling operations 
-- area calculation, 
-- intersection, 
-- relation analysis, 
-- and distance measurement between geometric objects

-- Title (a):  Spatial Databases
-- Create a spatial database table that stores the number, name and location, which consists of four different areas say abc, pqr, mno and xyz. Fire the following queries:
-- a) Find the topological intersection of two geometries.
-- b) Find whether two geometric figures are equivalent to each other.
-- c) Find the areas of all different locations.
-- d) Find the area of only one location.
-- e) Find the distance between two geometries.
 
-- Table Creation:
create table spatitab
     (mkt_id number primary key,
     name varchar2(32),
     shape MDSYS.SDO_GEOMETRY);
desc spatitab;

-- Inserting Records Into Table Spatitab: 
-- Query to insert the ‘abc’ shape in the table.
	insert into spatitab VALUES
     (
         1,
         'abc',
         MDSYS.SDO_GEOMETRY
         (
             2003,
             NULL,
             NULL,
             MDSYS.SDO_ELEM_INFO_ARRAY(1,1003,3),
             MDSYS.SDO_ORDINATE_ARRAY(1,1, 5,7)
         ));
 
-- Query to insert the ‘pqr’ shape in the table:
	insert into spatitab values
     (
         2,
         'pqr',
         MDSYS.SDO_GEOMETRY
         (
             2003,
             NULL,
             NULL,
             MDSYS.SDO_ELEM_INFO_ARRAY(1,1003,1),
             MDSYS.SDO_ORDINATE_ARRAY(5,1, 8,1, 8,6, 5,7, 5,1)
         ));

-- Query to insert the ‘mno’ shape in the table:
insert into spatitab values
     (
         3,
         'mno',
         MDSYS.SDO_GEOMETRY
         (
             2003,
             NULL,
             NULL,
             MDSYS.SDO_ELEM_INFO_ARRAY(1,1003,1),
             MDSYS.SDO_ORDINATE_ARRAY(3,3, 6,3, 6,5, 4,5, 3,3)
         ));

-- Query to insert the ‘xyz’ shape in the table:
insert into spatitab values
     (
         4,
         'xyz',
         MDSYS.SDO_GEOMETRY
         (
             2003,
             NULL,
             NULL,
             MDSYS.SDO_ELEM_INFO_ARRAY(1,1003,4),
             MDSYS.SDO_ORDINATE_ARRAY(8,7, 10,9, 8,11)
         ));

-- CREATING A METADATA :
-- To create a table called spatitab with an indexed spatial column, the following SQL statements are needed.
insert into USER_SDO_GEOM_METADATA values
     (
         'spatitab',
         'shape',
         MDSYS.SDO_DIM_ARRAY
         (
             MDSYS.SDO_DIM_ELEMENT('X', 0, 20, 0.005),
             MDSYS.SDO_DIM_ELEMENT('Y', 0, 20, 0.005)
         ),
         NULL);

-- Creating a spatial index i.e. table-column combination; here, spatitab and SHAPE.
CREATE INDEX spatitab_spatial_idx
     ON spatitab(shape)
     INDEXTYPE IS MDSYS.SPATIAL_INDEX;
Output:
 
-- Query 1: Find the topological intersection of two geometries.
select SDO_GEOM.SDO_INTERSECTION(c_a.shape, c_c.shape, 
     0.005)
     from spatitab c_a, spatitab c_c
     where c_a.name = 'abc' and c_c.name = 'mno';
 
-- Query 2: Find whether two geometric figures are equivalent to each other.
SELECT SDO_GEOM.RELATE(c_b.shape, 'ANYINTERACT', c_d.shape, 0.005) AS relation
FROM spatitab c_b, spatitab c_d
WHERE c_b.name = 'pqr' AND c_d.name = 'xyz';
Output:

select SDO_GEOM.RELATE(c_b.shape, 'anyinteract', c_a.shape, 
     0.005)
     from spatitab c_b, spatitab c_a
     where c_b.name = 'pqr' and c_a.name = 'abc';
 
-- Query 3:  Find the areas of all different locations.
SELECT name, 
       SDO_GEOM.SDO_AREA(shape, 0.005) AS area 
FROM spatitab;
 
-- Query 4: Find the area of only one location.
select c.name, SDO_GEOM.SDO_AREA(c.shape, 0.005)
     from spatitab c
     where c.name = 'abc';
 
-- Query 5: Find the distance between two geometries.
select SDO_GEOM.SDO_DISTANCE(c_b.shape, c_d.shape, 0.005)
     from spatitab c_b, spatitab c_d
     where c_b.name = 'pqr' and c_d.name = 'xyz';