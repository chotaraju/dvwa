-- Make a Hierarchical Mapping Object Relational Schema to XML which includes the following 
-- Exam (Exam_id , Year , Semester , class , course , marks) Course(Course_id , Course_name , faculty) 
-- Student(roll_no , name) 

-- Exam (Schema hierarchy)
-- Exam 
--    ├── ExamID 
--    ├── Year 
--    ├── Semester 
--    ├── Class 
--    ├── Course 
--    │ ├── CourseID 
--    │ ├── CourseName 
--    │ ├── Faculty 
--    │ ├── Marks 
--    │ ├── Student 
--    │ ├── RollNo 
--    │ ├── Name 

-- Table Creation
create table exam(exam_id number(5), exam_data XMLType); 

-- Data Insertion
INSERT INTO exam VALUES (
    101,
    XMLType('
        <Exam>
            <ExamID>EX001</ExamID>
            <Year>2024</Year>
            <Semester>1</Semester>
            <Class>10 A</Class>
            <Course>
                <CourseID>C001</CourseID>
                <CourseName>Mathematics</CourseName>
                <Faculty>Shubham</Faculty>
                <Marks>60</Marks>
                <Student>
                    <StudentID>S001</StudentID>
                    <StudentName>Deepak</StudentName>
                </Student>
            </Course>
        </Exam>')
);


INSERT INTO exam VALUES (
    102,
    XMLType('
        <Exam>
            <ExamID>EX002</ExamID>
            <Year>2024</Year>
            <Semester>2</Semester>
            <Class>10 B</Class>
            <Course>
                <CourseID>C002</CourseID>
                <CourseName>English</CourseName>
                <Faculty>Viraj</Faculty>
                <Marks>90</Marks>
                <Student>
                    <StudentID>S002</StudentID>
                    <StudentName>Durgesh</StudentName>
                </Student>
            </Course>
        </Exam>')
);

-- Extract Details of  Course Names for a Specific Exam
SELECT 
    e.exam_data.EXTRACT('//Course/CourseName/text()').getStringVal() AS "Course_Name"
FROM 
    exam e
WHERE 
    e.exam_data.EXTRACT('//ExamID/text()').getStringVal() = 'EX001';
 
-- Extract Details of Student for a Specific Course
SELECT 
    e.exam_data.EXTRACT('//Course[CourseID="C001"]/Student/StudentID/text()').getStringVal() AS "Student_ID",
    e.exam_data.EXTRACT('//Course[CourseID="C001"]/Student/StudentName/text()').getStringVal() AS "Student_Name"
FROM 
    exam e;

-- Checking  an existence of a Course for an exam using EXISTS
SELECT 
    CASE 
        WHEN e.exam_data.EXTRACT('//Course[CourseID="C002"]').getStringVal() IS NOT NULL 
        THEN 'Course Exists' 
        ELSE 'Course Does Not Exist' 
    END AS "Course_Existence"
FROM 
    exam e
WHERE 
    e.exam_data.EXTRACT('//ExamID/text()').getStringVal() = 'EX002';
 
-- Retrieve Exams Without Associated Students
SELECT 
    e.exam_data.EXTRACT('//ExamID/text()').getStringVal() AS "Exam_ID",
    e.exam_data.EXTRACT('//Class/text()').getStringVal() AS "Class"
FROM 
    exam e
WHERE 
    NOT EXISTS (
        SELECT 1
        FROM dual
        WHERE e.exam_data.EXTRACT('//Course/Student').getStringVal() IS NOT NULL
    );

-- Retrieve Specific Exam Details
SELECT 
    e.exam_data.EXTRACT('//ExamID/text()').getStringVal() AS "Exam_ID",
    e.exam_data.EXTRACT('//Class/text()').getStringVal() AS "Class",
    e.exam_data.EXTRACT('//Course/CourseName/text()').getStringVal() AS "Course_Name"
FROM 
    exam e
WHERE 
    e.exam_data.EXTRACT('//Class/text()').getStringVal() = '10 A'
    AND e.exam_data.EXTRACT('//Semester/text()').getStringVal() = '1';

-- Minimum and Maximum from Both Course
SELECT 
    MAX(TO_NUMBER(e.exam_data.EXTRACT('//Course/Marks/text()').getStringVal())) AS "Maximum_Marks",
    MIN(TO_NUMBER(e.exam_data.EXTRACT('//Course/Marks/text()').getStringVal())) AS "Minimum_Marks"
FROM exam e;

-- Counting Total students from both courses
SELECT 
  COUNT(e.exam_data.EXTRACT('//Course/Student/StudentID/text()').getStringVal()) AS "Total_Students"
FROM exam e;
