-- MongoDBCompass 

-- Open “mongod” exe file from the path C:\mongodb\bin  to enable the server
-- Create a Database with the name “Student” and inside it Create “Exam” as Collection.
-- Click on Add data >> insert document and then type the following.
-- Click on Insert.
-- Create one more like above.
-- Filter Condition: 
-- Validation: click on validation and update the following code using “add rule”
-- Open MongoDB Shell and execute the following
 
-- MONGODB ARRAY & NESTED OBJECTS
db.items.insert({"name": "Pants", "brand": "Staud", "price" : "$135", "qty" : 50, "type" : ["flare", "straight", "slim", "baggy", "bootcut"]})
db.items.insert({"name": "Tops", "brand": "Jacquemus", "price" : "$234", "qty" : 45, "type" : ["halter", "round", "crew", "tube", "tank", "peplum"]})
db.items.insert({"name": "Shoes", "brand": "Christian Louboutin", "price" : "$500", "qty" : 23, "details": {"alias" : "red-bottoms", "size" : [35, 36, 37, 38, 40]}})
db.items.find().forEach(printjson)

-- JOINING THE COLLECTION
db.inventory.insertMany( [
{ prodId: 100, price: 20, quantity: 125 },
{ prodId: 101, price: 10, quantity: 234 },
{ prodId: 102, price: 15, quantity: 432 },
{ prodId: 103, price: 17, quantity: 320 }
] )

db.orders.insertMany( [
{ orderId: 201, custid: 301, prodId: 100, numPurchased: 20 },
{ orderId: 202, custid: 302, prodId: 101, numPurchased: 10 },
{ orderId: 203, custid: 303, prodId: 102, numPurchased: 5 },
{ orderId: 204, custid: 303, prodId: 103, numPurchased: 15 },
{ orderId: 205, custid: 303, prodId: 103, numPurchased: 20 },
{ orderId: 206, custid: 302, prodId: 102, numPurchased: 1 },
{ orderId: 207, custid: 302, prodId: 101, numPurchased: 5 },
{ orderId: 208, custid: 301, prodId: 100, numPurchased: 10 },
{ orderId: 209, custid: 303, prodId: 103, numPurchased: 30 }
] )

db.createView("sales", "orders", [
  {
    $lookup: {
      from: "inventory",
      localField: "prodId",
      foreignField: "prodId",
      as: "inventoryDocs"
    }
  },
  {
    $project: {
      _id: 0,
      prodId: 1,
      orderId: 1,
      numPurchased: 1,
      price: { $arrayElemAt: ["$inventoryDocs.price", 0] }  // Get the first price
    }
  }
])

-- QUERY THE VIEW
db.sales.aggregate([
  {
    $group: {
      _id: "$prodId",
      amountSold: { $sum: { $multiply: ["$price", "$numPurchased"] } }
    }
  }
])