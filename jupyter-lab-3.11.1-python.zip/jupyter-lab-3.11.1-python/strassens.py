def read_matrix(filename, n):
    matrix = []
    with open(filename, 'r') as file:
        for _ in range(n):
            row = list(map(int, file.readline().split()))
            matrix.append(row)
    return matrix

def strassen_matrix_mult(A, B):
    n = len(A)
    if n == 1:
        result = [[0]]
        result[0][0] = A[0][0] * B[0][0]
        return result
    else:
        new_size = n // 2

        A11, A12, A21, A22 = divide_matrix(A, new_size)
        B11, B12, B21, B22 = divide_matrix(B, new_size)

        M1 = strassen_matrix_mult(add_matrices(A11, A22), add_matrices(B11, B22))
        M2 = strassen_matrix_mult(add_matrices(A21, A22), B11)
        M3 = strassen_matrix_mult(A11, subtract_matrices(B12, B22))
        M4 = strassen_matrix_mult(A22, subtract_matrices(B21, B11))
        M5 = strassen_matrix_mult(add_matrices(A11, A12), B22)
        M6 = strassen_matrix_mult(subtract_matrices(A21, A11), add_matrices(B11, B12))
        M7 = strassen_matrix_mult(subtract_matrices(A12, A22), add_matrices(B21, B22))

        C11 = subtract_matrices(add_matrices(add_matrices(M1, M4), M7), M5)
        C12 = add_matrices(M3, M5)
        C21 = add_matrices(M2, M4)
        C22 = subtract_matrices(add_matrices(add_matrices(M1, M3), M6), M2)

        result = combine_matrices(C11, C12, C21, C22, new_size)
        return result

def divide_matrix(parent, new_size):
    A11 = [row[:new_size] for row in parent[:new_size]]
    A12 = [row[new_size:] for row in parent[:new_size]]
    A21 = [row[:new_size] for row in parent[new_size:]]
    A22 = [row[new_size:] for row in parent[new_size:]]
    return A11, A12, A21, A22

def add_matrices(A, B):
    n = len(A)
    result = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            result[i][j] = A[i][j] + B[i][j]
    return result

def subtract_matrices(A, B):
    n = len(A)
    result = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            result[i][j] = A[i][j] - B[i][j]
    return result

def combine_matrices(C11, C12, C21, C22, new_size):
    result = [[0] * (2 * new_size) for _ in range(2 * new_size)]
    for i in range(new_size):
        for j in range(new_size):
            result[i][j] = C11[i][j]
            result[i][j + new_size] = C12[i][j]
            result[i + new_size][j] = C21[i][j]
            result[i + new_size][j + new_size] = C22[i][j]
    return result

def print_matrix(matrix):
    for row in matrix:
        print(" ".join(map(str, row)))

if __name__ == "__main__":
    A = read_matrix("matrix1.txt", 4)
    B = read_matrix("matrix2.txt", 4)

    result = strassen_matrix_mult(A, B)

    print("Resultant Matrix:")
    print_matrix(result)
