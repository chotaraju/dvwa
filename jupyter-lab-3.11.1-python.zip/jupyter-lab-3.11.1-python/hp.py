import random

def hire_candidate(candidate_info):
    best_candidate = None
    best_iq = -1

    for name, iq in candidate_info:
        if iq > best_iq:
            best_candidate = name
            best_iq = iq
    
    if best_candidate is not None:
        print(f"\n{best_candidate} has the best IQ of {best_iq} among the other candidates interviewed.")

# Input: List of (name, IQ) pairs
candidate_info = []

n = int(input("Enter the number of candidates:"))

for i in range(n):
    name = input(f"Enter the name of candidate {i+1}: ")
    iq = int(input(f"Enter the IQ of candidate {i+1}: "))
    candidate_info.append((name, iq))

# Shuffle the candidate list randomly
random.shuffle(candidate_info)

print("\nAfter Shuffling")
for name, iq in candidate_info:
    print(f"{name}: {iq}")

hire_candidate(candidate_info)
