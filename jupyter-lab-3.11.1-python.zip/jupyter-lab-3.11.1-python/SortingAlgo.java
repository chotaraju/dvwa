import java.util.Scanner;
import java.util.Arrays;
public class SortingAlgo {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Select a sorting algorithm: \n");
        System.out.println("1. Bubble Sort \n");
        System.out.println("2. Heap Sort \n");
        System.out.println("3. Selection Sort \n");
        System.out.println("4. Insertion Sort \n");

        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();

        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();

         int[] arr = new int[size];
          System.out.println("Enter " +size+   " numbers: ");
           
         for(int i=0; i<size; ++i)  
         {  
            //reading array elements from the user   
	    	arr[i]=scanner.nextInt();  
        } 
          System.out.println("Original Array:");
        printArray(arr);
        
        long startTime = 0;
        long endTime = 0;
        int totalSteps = 0;

        switch (choice) {
            case 1:
                System.out.println("Bubble Sort:");
                startTime = System.nanoTime();
                totalSteps = bubbleSort(arr);
                endTime = System.nanoTime();
                break;
            case 2:
                System.out.println("Heap Sort:");
                startTime = System.nanoTime();
                totalSteps = heapSort(arr);
                endTime = System.nanoTime();
                break;
            case 3:
                System.out.println("Selection Sort:");
                startTime = System.nanoTime();
                totalSteps = selectionSort(arr);
                endTime = System.nanoTime();
                break;
            case 4:
                System.out.println("Insertion Sort:");
                startTime = System.nanoTime();
                totalSteps = insertionSort(arr);
                endTime = System.nanoTime();
                break;
            default:
                System.out.println("Invalid choice.");
                return;
        }

        long elapsedTime = endTime - startTime;

        System.out.println("\nSorted Array: " + Arrays.toString(arr));
        System.out.println("\n Total Steps: " + totalSteps);
        System.out.println("\n Time Taken (ns): " + elapsedTime);

        scanner.close();
    }


    public static int bubbleSort(int[] arr) {
        int steps = 0;
        int n = arr.length;
        for (int i = 0; i < n - 1; ++i) {
            for (int j = 0; j < n - i - 1; ++j) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    steps++;
                }
            }
        }
        return steps;
    }

    public static int heapSort(int[] arr) {
        int steps = 0;
        int step= 0;
        int n = arr.length;
        for (int i = n / 2 - 1; i >= 0; --i) {
            step = heapify(arr, n, i);
            steps = steps + step;
        }

        for (int i = n - 1; i >= 0; --i) { 
            int temp = arr[0];
            arr[0] = arr[i];
            arr[i] = temp;
            steps++;
            step = heapify(arr, i, 0);
            steps = steps + step;
        }
        return steps;
    }

    public static int heapify(int[] arr, int n, int i) {
        int steps = 0;
        int step= 0;
       
        int largest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        if (left < n && arr[left] > arr[largest]) {
            largest = left;
        }

        if (right < n && arr[right] > arr[largest]) {
            largest = right;
        }

        if (largest != i) {
            int temp = arr[i];
            arr[i] = arr[largest];
            arr[largest] = temp;
            steps++;
            step = heapify(arr, n, largest);
            steps = steps+step;
        }
        return steps;
    }

    public static int insertionSort(int[] arr) {
        int steps = 0;
        int n = arr.length;
        for (int i = 1; i < n; ++i) {
            int key = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                //steps++;
                --j;
            }
            arr[j + 1] = key;
            steps++;
        }
        return steps;
    }
    
    public static int selectionSort(int[] arr) {
        int steps = 0;
        int n = arr.length;
        for (int i = 0; i < n - 1; ++i) {
            int min_idx = i;
            for (int j = i + 1; j < n; ++j) {
                if (arr[j] < arr[min_idx]) {
                    min_idx = j;
                }
            }
            int temp = arr[i];
            arr[i] = arr[min_idx];
            arr[min_idx] = temp;
            steps++;
        }
        return steps;
}

 static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
