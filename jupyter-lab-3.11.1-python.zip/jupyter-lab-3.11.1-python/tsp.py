import sys

# number of cities and the adjacency matrix
NUM_CITIES = 4
adjacency = [
    [12, 30, 33, 10],
    [56, 22, 9, 15],
    [29, 13, 8, 5],
    [33, 28, 16, 10]
]

def tsp(currentCity, mask, numCities, dp, parent):
    if mask == (1 << numCities) - 1:
        return adjacency[currentCity][0]

    if dp[currentCity][mask] != -1:
        return dp[currentCity][mask]

    minCost = sys.maxsize
    nextCityIdx = -1

    for nextCity in range(numCities):
        if (mask & (1 << nextCity)) == 0 and adjacency[currentCity][nextCity] != 0:
            newMask = mask | (1 << nextCity)
            cost = adjacency[currentCity][nextCity] + tsp(nextCity, newMask, numCities, dp, parent)
            if cost < minCost:
                minCost = cost
                nextCityIdx = nextCity

    dp[currentCity][mask] = minCost
    parent[currentCity][mask] = nextCityIdx
    return minCost

def printPath(currentCity, mask, parent):
    if mask == (1 << NUM_CITIES) - 1:
        return

    nextCity = parent[currentCity][mask]
    print(nextCity, "->", end=" ")
    printPath(nextCity, mask | (1 << nextCity), parent)

if __name__ == "__main__":
    dp = [[-1 for _ in range(1 << NUM_CITIES)] for _ in range(NUM_CITIES)]
    parent = [[-1 for _ in range(1 << NUM_CITIES)] for _ in range(NUM_CITIES)]

    minCost = tsp(0, 1, NUM_CITIES, dp, parent) # Start from city 0
    print("Minimum Cost:", minCost)
    print("Shortest Path: 0 ->", end=" ")
    printPath(0, 1, parent)
    print("0")
