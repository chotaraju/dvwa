def rod_cutting(n, prices):
    dp = [-float('inf')] * (n + 1)
    # table to store the sizes for each rod length.
    cut_sizes = [0] * (n + 1)

    #The profit for a rod of length 0 is 0.
    dp[0] = 0

    # DP table bottom-up.
    for i in range(1, n + 1):
        for j in range(1, i + 1):
            if prices[j] + dp[i - j] > dp[i]:
                dp[i] = prices[j] + dp[i - j]
                cut_sizes[i] = j

    # maximum profit and the cut sizes.
    max_profit = dp[n]
    max_cut_size = n

    # List to store all cut combinations
    cut_combinations = []

    while max_cut_size > 0:
        cut_combination = [cut_sizes[max_cut_size]]
        remaining_length = max_cut_size - cut_sizes[max_cut_size]

        while remaining_length > 0:
            cut_combination.append(cut_sizes[remaining_length])
            remaining_length -= cut_sizes[remaining_length]

        cut_combinations.append(cut_combination)
        max_cut_size -= 1

    print("All Possible Cut Combinations:")
    for i, combination in enumerate(cut_combinations):
        total_profit = sum(prices[size] for size in combination)
        print(f"Combination {i + 1}: {combination} (Total Profit: {total_profit})")
    print(f"Maximum Profit for Rod of Length {n}: {max_profit}")
    
if __name__ == "__main__":
    rod_length = int(input("Enter the length of the rod: "))
    prices = [0, 1, 5, 8, 9, 10, 17, 17, 20, 24, 30]

    rod_cutting(rod_length, prices)
