def longest_common_parallel_subsequence(X, Y):
    m, n = len(X), len(Y)
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    max_length = 0
    end_index = 0

    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if X[i - 1] == Y[j - 1]:
                dp[i][j] = dp[i - 1][j - 1] + 1
                if dp[i][j] > max_length and (i - dp[i][j]) == (j - dp[i][j]):
                    max_length = dp[i][j]
                    end_index = i

    start_index = end_index - max_length
    subset = X[start_index:end_index]

    return subset, max_length

def main():
    file1 = input("Enter the path to the first input file: ")
    file2 = input("Enter the path to the second input file: ")

    with open(file1, 'r') as f1, open(file2, 'r') as f2:
        seq1 = f1.read().strip()
        seq2 = f2.read().strip()

    subset, length = longest_common_parallel_subsequence(seq1, seq2)

    print("Longest Common Parallel Subsequence:", subset)
    print("Total Count:", length)

if __name__ == "__main__":
    main()
