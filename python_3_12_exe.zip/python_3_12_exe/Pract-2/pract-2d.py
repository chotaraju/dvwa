# Map Words to Properties Using Python Dictionaries
thisdict={
    "brand":"Porsche",
    "model":"911 gt3 rs",
    "year":2003
    }

print(thisdict)
print(thisdict["brand"])
print(len(thisdict))
print(type(thisdict))
