# Study of tagged corpora with methods like tagged_sents, tagged_words.
import nltk
nltk.download('punkt')
nltk.download('words')
from nltk import tokenize
para = "Hello World! From kirti college. Today we will be learning NLTK."
sents = tokenize.sent_tokenize(para)
print("\nsentence tokenization\n=========\n", sents)

print("\nword tokenization\n========\n")
for index in range(len(sents)):
    words = tokenize.word_tokenize(sents[index])
    print(words)
