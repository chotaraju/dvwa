// npm install -g create-react-app
// npx create-react-app app-name
// index.js
// npm start

import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function Booklist() {
  return (
    <table>
      <section>
        <td><Book /></td>
        <td><Book /></td>
        <td><Book /></td>
      </section>
    </table>
  );
}

const Book = () => {
  return (
    <article>
      <Image />
      <Title />
      <Author />
    </article>
  );
};
const Image = () => <img src='https://rukminim2.flixcart.com/image/416/416/xif0q/book/h/g/g/don-t-believe-everything-you-think-original-imah5tegrcrhzzrh.jpeg' alt='' width='300px' />
const Title = () => <h1>Don't Believe Everything You Think</h1>
const Author = () => <h3>by Joseph Nguyen </h3>
ReactDOM.render(<Booklist />, document.getElementById('root'));

// index.css
body {
    margin: 0;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
    background: whitesmoke;
    color: crimson;
    padding: 50px;
  
  }
  
  img {
    margin: 20px;
    width: 200px;
  }
  
  h1 {
    margin: 20px;
    font-size: 18px;
  }
  
  h3 {
   font-size: 12px;
   margin: 20px;
  }