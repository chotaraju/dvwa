// npm install -g create-react-app
// npx create-react-app app-name
// app.js
// npm start

import React, { useState } from 'react';
import './App.css';

const FormValidationExample = () => {
  const [formData, setFormData] = useState({
    username: '', email: '', password: '', confirmPassword: ''
  });
  const [errors, setErrors] = useState({});

  const handleChange = ({ target: { name, value } }) => 
    setFormData({ ...formData, [name]: value });

  const validate = () => {
    const validationErrors = {};
    const { username, email, password, confirmPassword } = formData;

    if (!username.trim()) validationErrors.username = "Username is required";
    if (!email.trim()) validationErrors.email = "Email is required";
    else if (!/\S+@\S+\.\S+/.test(email)) validationErrors.email = "Invalid email";
    if (!password.trim()) validationErrors.password = "Password is required";
    else if (password.length < 6) validationErrors.password = "Password must be at least 6 characters";
    if (password !== confirmPassword) validationErrors.confirmPassword = "Passwords do not match";

    return validationErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (!Object.keys(validationErrors).length) alert("Form Submitted successfully");
  };

  const renderInput = (label, name, type = "text", placeholder) => (
    <div>
      <label>{label}:</label>
      <input
        type={type}
        name={name}
        placeholder={placeholder}
        autoComplete="off"
        onChange={handleChange}
      />
      {errors[name] && <span>{errors[name]}</span>}
    </div>
  );

  return (
    <form onSubmit={handleSubmit}>
      {renderInput("Username", "username", "text", "Username")}
      {renderInput("Email", "email", "email", "example@gmail.com")}
      {renderInput("Password", "password", "password", "******")}
      {renderInput("Confirm Password", "confirmPassword", "password", "******")}
      <button type="submit">Submit</button>
    </form>
  );
};

export default FormValidationExample;


// app.css
/* Styles for the form container */
* {
    box-sizing: border-box;
  }
  
  form {
    max-width: 400px;
    margin: 100px 50px 30px 520px;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  }
  
  
  /* Styles for the form fields and labels */
  form div {
    margin-bottom: 15px;
  }
  
  
  label {
    display: block;
    font-weight: bold;
  }
  
  
  input {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
  }
  
  
  /* Styles for error messages */
  span {
    color: #e74c3c;
    font-size: 14px;
    margin-top: 5px;
    display: block;
  }
  
  
  /* Styles for the submit button */
  button {
    background-color: #3498db;
    color: #fff;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
  }
  
  
  button:hover {
    background-color: #2980b9;
  }