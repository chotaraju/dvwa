// npm init
// npm install express mongoose mongodb
// node index.js

const express = require('express')
const mongoose = require('mongoose');

const User = require('./models/user')

const app = express()

app.use(express.json())

app.get('/', async (req, res) => {
    const users = await User.find()
    return res.json(users)
})

app.post('/user', async (req, res) => {
    const body = req.body
    console.log(body)
    const createdUsers = await Promise.all(body.map(async (user) => {
        const newUser = new User(user)
        return await newUser.save()
    }))
    return res.json(createdUsers)
})

mongoose.connect('mongodb://localhost:27017/', 
    {retryWrites: true, appName: 'MongoAPP'})
    .then(res => {
        app.listen(8081)
    })