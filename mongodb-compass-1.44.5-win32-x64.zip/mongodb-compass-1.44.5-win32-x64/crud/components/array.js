// Filename - components/array.js

const array = [
    {
        id: "1",
        Name: "Viraj",
        Age: "23",
    },
    {
        id: "2",
        Name: "Deepak",
        Age: "22",
    },
    {
        id: "3",
        Name: "Pratham",
        Age: "23",
    },
];

export default array;
