// Filename - components/Create.js

import React, { useState } from "react";
import { Button, Form } from "react-bootstrap";
import { v4 as uuid } from "uuid";
import { Link, useNavigate } from "react-router-dom";
import array from "./array";
import "bootstrap/dist/css/bootstrap.min.css";

const Create = () => {
    const [name, setName] = useState("");
    const [age, setAge] = useState("");
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!name || !age) return alert("Invalid input");
        
        array.push({ id: uuid().slice(0, 8), Name: name, Age: age });
        navigate("/");
    };

    return (
        <Form className="d-grid gap-2" style={{ margin: "5rem" }} onSubmit={handleSubmit}>
            <Form.Group className="mb-3">
                <Form.Control onChange={(e) => setName(e.target.value)} type="text" placeholder="Enter Name" required />
            </Form.Group>
            <Form.Group className="mb-3">
                <Form.Control onChange={(e) => setAge(e.target.value)} type="number" placeholder="Age" required />
            </Form.Group>
            <Button variant="primary" type="submit">Submit</Button>
            <Link to="/" className="d-grid gap-2">
                <Button variant="info">Home</Button>
            </Link>
        </Form>
    );
};

export default Create;
