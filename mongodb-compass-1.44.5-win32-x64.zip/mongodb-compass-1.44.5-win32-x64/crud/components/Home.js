// Filename - components/Home.js

import React from "react";
import { Button, Table } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import array from "./array";
import "bootstrap/dist/css/bootstrap.min.css";

const Home = () => {
    const navigate = useNavigate();

    const setID = (id, name, age) => {
        localStorage.setItem("id", id);
        localStorage.setItem("Name", name);
        localStorage.setItem("Age", age);
    };

    const deleteEntry = (id) => {
        const index = array.findIndex((item) => item.id === id);
        if (index > -1) {
            array.splice(index, 1);
            navigate("/");
        }
    };

    return (
        <div style={{ margin: "2rem" }}>
            <h1 className="text-center mb-4">User Management</h1>
            <Table striped bordered hover responsive>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {array.map((item) => (
                        <tr key={item.id}>
                            <td>{item.Name}</td>
                            <td>{item.Age}</td>
                            <td>
                                <Link to="/edit">
                                    <Button onClick={() => setID(item.id, item.Name, item.Age)} variant="info" className="me-2">Update</Button>
                                </Link>
                                <Button onClick={() => deleteEntry(item.id)} variant="danger">Delete</Button>
                            </td>                            
                        </tr>
                    ))}
                </tbody>
            </Table>
            <Link to="/create">
                <Button variant="success" size="lg">Create New User</Button>
            </Link>
        </div>
    );
};

export default Home;
