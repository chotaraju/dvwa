// Filename - components/edit.js

import React, { useEffect, useState } from "react";
import { Button, Form } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import array from "./array";
import "bootstrap/dist/css/bootstrap.min.css";

const Edit = () => {
    const [name, setName] = useState("");
    const [age, setAge] = useState("");
    const id = localStorage.getItem("id");
    const navigate = useNavigate();

    useEffect(() => {
        setName(localStorage.getItem("Name"));
        setAge(localStorage.getItem("Age"));
    }, []);

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!name || !age) return alert("Invalid input");

        const item = array.find((item) => item.id === id);
        if (item) {
            item.Name = name;
            item.Age = age;
        }
        navigate("/");
    };

    return (
        <Form className="d-grid gap-2" style={{ margin: "5rem" }} onSubmit={handleSubmit}>
            <Form.Group className="mb-3">
                <Form.Control value={name} onChange={(e) => setName(e.target.value)} type="text" placeholder="Enter Name" />
            </Form.Group>
            <Form.Group className="mb-3">
                <Form.Control value={age} onChange={(e) => setAge(e.target.value)} type="number" placeholder="Age" />
            </Form.Group>
            <Button variant="primary" type="submit">Update</Button>
            <Link to="/" className="d-grid gap-2">
                <Button variant="warning">Home</Button>
            </Link>
        </Form>
    );
};

export default Edit;
