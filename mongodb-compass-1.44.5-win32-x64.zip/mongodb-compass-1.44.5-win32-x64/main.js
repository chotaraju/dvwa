/**

hello.js - To Create React First app &amp; display Hello world with the help of components.

book.js - To Create the first react app (booklist) with components

eventform.js - Creating a form in react js using components properties &amp; state.

formvalid.js - To create Form Validation in React js

crud - CRUD operations in ReactJS

usertype - Creating a Simple User Input Display Web Application using TypeScript & HTML.

calctype - Creating a calculator using Typescript & Html

mongo - Nodejs with Mongodb
 
**/