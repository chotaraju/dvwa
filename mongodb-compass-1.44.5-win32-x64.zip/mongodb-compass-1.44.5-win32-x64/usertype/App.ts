const number1 = document.getElementById("num1") as HTMLInputElement
const printButton = document.getElementById("printBtn") as HTMLButtonElement
const printvalue = document.getElementById("enterednumber") as HTMLOutputElement

function printEnteredValue(): void {
    const numb1 = parseFloat(number1.value); 
    printvalue.textContent = numb1.toString();
}

printButton.addEventListener("click", printEnteredValue);


// npm i -g typescript
// tsc App.ts
