// npm install -g create-react-app
// npx create-react-app app-name
// index.js
// npm start

import React from 'react';
import ReactDOM from 'react-dom';

//stateless component
const Hello = () => {
  return React.createElement('h1', {}, 'Hello World');
}

ReactDOM.render(<Hello />,
  document.getElementById('root')
);
