# Double Link List

class Node:                     #(first class)
    def __init__(self, data):
        self.data = data
        self.prev = None
        self.next = None


class DoublyLinkedList:          #(second class)
    def __init__(self):
        self.head = None


    def append(self, data):      
        new_node = Node(data)
        if not self.head:
            self.head = new_node
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = new_node
            new_node.prev = current


    def insert_at_position(self, data, position):
        new_node = Node(data)


        if position == 1:
            new_node.next = self.head
            self.head.prev = new_node
            self.head = new_node
        else:
            current = self.head
            for _ in range(position - 2):
                if current.next:
                    current = current.next
                else:
                    print("Invalid position")
                    return


            new_node.next = current.next
            new_node.prev = current
            if current.next:
                current.next.prev = new_node
            current.next = new_node


    def delete_at_position(self, position):
        if not self.head:
            print("List is empty")
            return


        if position == 1:
            self.head = self.head.next
            if self.head:
                self.head.prev = None
        else:
            current = self.head
            for _ in range(position - 1):
                if current.next:
                    current = current.next
                else:
                    print("Invalid position")
                    return


            if current.prev:
                current.prev.next = current.next
            if current.next:
                current.next.prev = current.prev


    def display(self):
        current = self.head
        while current:
            print(current.data, end=" ")
            current = current.next
        print()


dll = DoublyLinkedList()


while True:
    print("1. Append node")
    print("2. Insert at position")
    print("3. Delete at position")
    print("4. Display list")
    print("5. Quit")


    choice = input("Enter your choice: ")


    if choice == '1':
        data = input("Enter data for the new node: ")
        dll.append(data)
    elif choice == '2':
        data = input("Enter data for the new node: ")
        position = int(input("Enter position to insert: "))
        dll.insert_at_position(data, position)
    elif choice == '3':
        position = int(input("Enter position to delete: "))
        dll.delete_at_position(position)
    elif choice == '4':
        print("Doubly Linked List:")
        dll.display()
    elif choice == '5':
        break
    else:
        print("Invalid choice. Please enter 1, 2, 3, 4, or 5.")