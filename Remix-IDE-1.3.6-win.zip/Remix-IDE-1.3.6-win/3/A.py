# Single Block of Blockchain OR Single Block: One transaction
import hashlib
from datetime import datetime
import random

class Block:
    def __init__(self, block_id, prev_hash, transactions):
        self.block_id = block_id
        self.timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.nonce = random.randint(10000, 99999)
        self.prev_hash = prev_hash
        self.transactions = transactions
        self.merkle_root = hashlib.sha256(str(transactions[0]).encode()).hexdigest()

    def display_block_details(self):
        print(f"Block ID: {self.block_id}")
        print(f"Timestamp: {self.timestamp}")
        print(f"Nonce: {self.nonce}")
        print(f"Previous Hash: {self.prev_hash}")
        print(f"Transaction: {self.transactions}")
        print(f"Merkle Root: {self.merkle_root}")

# Example Usage:
block_id = 1
prev_hash = "0"
transactions = [{"sender": "User1", "receiver": "User2", "amount": 500}]

block = Block(block_id, prev_hash, transactions)
block.display_block_details()
