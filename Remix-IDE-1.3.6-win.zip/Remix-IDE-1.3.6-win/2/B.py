# Encryption and Decryption OR program to apply encryption and decryption by any three algorithms

def caesar_cipher(text, shift):
    result = ''
    for char in text:
        if char.isalpha():
            if char.isupper():
                result += chr((ord(char) + shift - 65) % 26 + 65)
            else:
                result += chr((ord(char) + shift - 97) % 26 + 97)
        else:
            result += char
    return result

def xor_cipher(text, key):
    result = ''
    for char in text:
        result += chr(ord(char) ^ key)
    return result

def substitution_cipher(text, key):
    alphabet = 'abcdefghijklmnopqrstuvwxyz'
    result = ''
    for char in text:
        if char.isalpha():
            if char.isupper():
                result += key[alphabet.index(char.lower())].upper()
            else:
                result += key[alphabet.index(char)]
        else:
            result += char
    return result

# Example usage:
original_text = "Hello, World!"
shift_amount = 3
xor_key = 10
substitution_key = "zyxwvutsrqponmlkjihgfedcba"

# Encryption
encrypted_caesar = caesar_cipher(original_text, shift_amount)
encrypted_xor = xor_cipher(original_text, xor_key)
encrypted_substitution = substitution_cipher(original_text, substitution_key)

print("Original Text:", original_text)
print("Caesar Cipher (Encrypted):", encrypted_caesar)
print("XOR Cipher (Encrypted):", encrypted_xor)
print("Substitution Cipher (Encrypted):", encrypted_substitution)

# Decryption
decrypted_caesar = caesar_cipher(encrypted_caesar, -shift_amount)
decrypted_xor = xor_cipher(encrypted_xor, xor_key)
decrypted_substitution = substitution_cipher(encrypted_substitution, substitution_key)

print("\nDecrypted using Caesar Cipher:", decrypted_caesar)
print("Decrypted using XOR Cipher:", decrypted_xor)
print("Decrypted using Substitution Cipher:", decrypted_substitution)
