# Hash Generation OR generate hash by any three algorithms

import hashlib

def generate_hash(data, algorithm):
    hash_function = hashlib.new(algorithm)
    hash_function.update(data.encode('utf-8'))
    return hash_function.hexdigest()

data_to_hash = "Hello, World!"

md5_hash = generate_hash(data_to_hash, 'md5')
sha256_hash = generate_hash(data_to_hash, 'sha256')
sha512_hash = generate_hash(data_to_hash, 'sha512')

print(f"MD5 Hash: {md5_hash}")
print(" ")
print(" ")
print(f"SHA-256 Hash: {sha256_hash}")
print(" ")
print(" ")
print(f"SHA-512 Hash: {sha512_hash}")
