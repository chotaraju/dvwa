practical 4:Open the file wait let for 2 mins let all connections to be ready once all connections are ready 
	    click on router 1 go to cli tab press enter type show ip route and press enter

practical 5:Open the file wait let for 2 mins let all connections to be ready once all connections are ready 
	    click on laptop 0 go to config tab>>> click on wireless0 >>>In Ip address type 192.168.100.4 press enter 
	    click on laptop 1 go to config tab>>> click on wireless0 >>>In Ip address type 192.168.100.2 press enter
	    click on laptop0 go to desktop and open command prompt and type ping 192.168.100.100(ping the server)
	    click on laptop1 go to desktop and open command prompt and type ping 192.168.100.4(ping the laptop0


practical 6:Open the file wait let for 2 mins let all connections to be ready once all connections are ready 
	    Click on wireless router go to gui tab >>>click on wireless>>> click on wireless mac filters>>>
	    select prevent pc or permit pc option and scroll down click on save setting

practical 7:Open the file wait let for 2 mins let all connections to be ready once all connections are ready 
	    press alt and left click on motion detector sensor with mouse(to access gateway click on smartphone 
	    in desktop tab open brower type 192.168.25.1 username:admin password:admin)

practical 8:Open the file wait let for 2 mins let all connections to be ready once all connections are ready 
	    click on smartphone>>>Go to Desktop tab and open command prompt and type ping 20.1.1.1 and press enter 