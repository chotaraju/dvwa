#loading datsets
library(tidyverse)

#loading dataset
library(readxl)
Olympic <- read_excel("D:/Data-Set/Summer-Olympic-medals-1976-to-2008.xlsx")
View(Olympic)

#plotting
ggplot(data = Olympic) + geom_bar(mapping = aes(x = Gender))

#using count
Olympic %>% count(Gender)

#distribution of a continuous variable
ggplot(data = Olympic) + geom_histogram(mapping = aes(x = Year), binwidth = 0.5)

#combining dplyr::count() and ggplot2::cut_width():
Olympic %>% count(cut_width(Year, 0.5))
