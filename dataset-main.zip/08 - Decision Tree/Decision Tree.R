#Loading libraries
library(datasets)
library(caTools)
library(party)
library(dplyr)
library(magrittr)

data("readingSkills")
head(readingSkills)

#Splitting dataset into 4:1 ratio for train and test data
sample_data = sample.split(readingSkills, SplitRatio = 0.8)
train_data <- subset(readingSkills, sample_data == TRUE)
test_data <- subset(readingSkills, sample_data == FALSE)

#Create the decision tree model using ctree and plot the model 
model<- ctree(nativeSpeaker ~ ., train_data)
plot(model)

#Making a prediction  
predict_model<-predict(ctree(nativeSpeaker ~ ., train_data), test_data)

#creates a table to count how many are classified
m_at <- table(test_data$nativeSpeaker, predict_model)
m_at

#Determining the accuracy of the model developed 
ac_Tst <- sum(diag(m_at)) / sum(m_at)
print(paste('Accuracy for test is found to be', ac_Tst))

