# Loading required libraries
library(tidyverse)
library(nycflights13)

# Adding Datasets 
library(readxl)
Consumer_Price <- read_excel("D:/Data-Set/All India Consumer Price Index (RuralUrban) upto October 2022.xls", 
                             col_types = c("text", "numeric", "numeric", "numeric", "numeric", "numeric", 
                                           "numeric", "numeric", "numeric", "numeric", "numeric", "numeric"))
View(Consumer_Price)

#filter()
df <- tibble(x = c(1, NA, 3))
filter(df, x > 1)

##Missing Values
filter(df, is.na(x) | x > 1)

#na.rm
Consumer_Price %>%
  group_by(Sector, Year, Month) %>%
  summarize(mean = mean(Education, na.rm = TRUE))

not_cancelled <- flights %>%
  filter(!is.na(dep_delay), !is.na(arr_delay))

not_cancelled %>%
  group_by(year, month, day) %>%
  summarize(mean = mean(dep_delay))