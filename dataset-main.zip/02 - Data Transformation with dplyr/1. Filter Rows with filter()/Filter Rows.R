# Loading required libraries
library(tidyverse)
library(nycflights13)

# Adding Datasets 
library(readxl)
Consumer_Price <- read_excel("D:/Data-Set/All India Consumer Price Index (RuralUrban) upto October 2022.xls", 
                             col_types = c("text", "numeric", "numeric", "numeric", "numeric", "numeric", 
                                           "numeric", "numeric", "numeric", "numeric", "numeric", "numeric"))
View(Consumer_Price)

#to see all sectors of 2013 in the month of january
filter(Consumer_Price, Year == 2013, Month == 1)

#assignment <- operator to save it into a variable
jan1 <- filter(Consumer_Price, Year == 2013, Month == 1)
jan1

#to print out out the results
(dec25 <- filter(Consumer_Price, Year == 2013, Month == 12))
dec25

#finds all products in the month of November and December.
filter(Consumer_Price, Month == 11 | Month == 12)

#This will select every row where x is one of the values in y.
nov_dec <- filter(Consumer_Price, Month %in% c(11, 12))
nov_dec

#more than 120
filter(Consumer_Price, !(Fruits > 120 | Vegetables > 120))

#less than/equal 120
filter(Consumer_Price, Fruits <= 120 | Vegetables <= 120)