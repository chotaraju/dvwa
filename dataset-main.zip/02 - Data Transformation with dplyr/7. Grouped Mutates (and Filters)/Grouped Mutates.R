# Loading required libraries
library(tidyverse)
library(nycflights13)

#creating flights_sml
flights_sml <- select(flights,
                      year:day,
                      ends_with("delay"),
                      distance,
                      air_time
)

#Find the worst members of each group
flights_sml %>% group_by(year, month, day) %>% filter(rank(desc(arr_delay)) < 10)

#Find all groups bigger than a threshold
popular_dests <- flights %>% group_by(dest) %>% filter(n() > 365)
popular_dests

#Standardize to compute per group metrics
popular_dests %>% filter(arr_delay > 0) %>%
  mutate(prop_delay = arr_delay / sum(arr_delay)) %>%
  select(year:day, dest, arr_delay, prop_delay)
