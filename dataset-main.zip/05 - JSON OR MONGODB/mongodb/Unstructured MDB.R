##Installing and loading required packages
library(ggplot2)
library(dplyr)
install.packages("ggmap")
library(ggmap)
library(maps)
install.packages("mongolite")
library(mongolite)
install.packages("lubridate")
library(lubridate)
install.packages("gridExtra")
library(gridExtra)
crimes=data.table::fread("D:/Data-Set/Persons Arrested under Cyber Crimes (IT Act, IPC Crimes, SLL Crimes) by Age Groups & Sex During 2015.csv")
names(crimes)

#Inserting data

#remove spaces in the column names
names(crimes) = gsub(" ","",names(crimes))
names(crimes)

#create a database
my_collection = mongo(collection = "crimes", db = "India")

#insert
my_collection$insert(crimes)
my_collection$count()

#Performing a query and retrieving data
my_collection$iterate()$one()

#How many “Category Type” do we have?
length(my_collection$distinct("Category"))

#To get the filtered data and we can also retrieve only the columns of interest
query1= my_collection$find('{"Category" : "Offences under IT Act", "CrimeHead" : "4.1 Under section 67A" }')

query2= my_collection$find('{"Category" : "Offences under IT Act", "CrimeHead" : "4.1 Under section 67A" }', fields = '{"Below18YearsJuveniles-Male":1, "Below18YearsJuveniles-Female":1}')

# with all the columns
ncol(query1) 

# only the selected columns
ncol(query2) 


#Where do most crimes take pace?
my_collection$aggregate('[{"$group":{"_id":"$Category", "Count": {"$sum":1}}}]')%>%
  na.omit()%>%arrange(desc(Count))%>%head(10)%>%
  ggplot(aes(x=reorder(`_id`,Count),y=Count))+
  geom_bar(stat="identity",color='yellow',fill='#000B49')+geom_text(aes(label = Count), color = "hotpink") +
  coord_flip()+xlab("Category")

query3= my_collection$find('{}', fields = '{"Category":1, "CrimeHead":1,"Below18YearsJuveniles-Male":1}')

#most common ones
crimes=my_collection$find('{}', fields = '{"Category":1,"18YearsandAbove-Below30Years-Male":1}')
crimes%>%group_by(Category)%>%summarize(Count=n())%>%arrange(desc(Count))%>%head(4)

