## Read a JSON file

#install package
install.packages("rjson")

# Load the package required to read JSON files.
library("rjson")

# Give the input file name to the function.
fintech <- fromJSON(file = "D:/Data-Set/fintech.json")

# Print the result.
print(fintech)


## Writing into JSON file.

# creating the list
list1 <- vector(mode="list", length=2)
list1[[1]] <- c("Abdu", "MC Stan", "Selemon Bhoi")
list1[[2]] <- c("Singer x boxer", "rapper and music producer", "Bhoi x BB")

# creating the data for JSON file
jsonData <- toJSON(list1)

# writing into JSON file
write(jsonData, "D:/Data-Set/result.json")

# Give the created file name to the function
result <- fromJSON(file = "D:/Data-Set/result.json")

# Print the result
print(result)


## Convert the file into dataframe

# Give the input file name to the function.
fintech <- fromJSON(file = "D:/Data-Set/fintech.json")

# Convert JSON file to a data frame.
json_data_frame <- as.data.frame(fintech)

print(json_data_frame)
