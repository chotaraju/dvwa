# Loading required libraries 
library(tidyverse) 
library(readxl) 

# Adding Datasets 
Road_Accidents <- read_excel("D:/Data-Set/StateUTs-wise Total Number of Road Accidents and Persons killed on National Highways including Expressways from 2017 to 2020.xls")
View(Road_Accidents)

# Loading dataset
Road_Accidents

ggplot(data = Road_Accidents) + 
  geom_point(mapping = aes(x = Persons_killed_2018, y = Road_Accidents_2018)) + 
  facet_wrap(~ States_UTs, nrow = 2) 
