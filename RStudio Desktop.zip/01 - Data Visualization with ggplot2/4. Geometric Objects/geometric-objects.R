# Loading required libraries 
library(tidyverse)
library(readxl)

# Adding Datasets 
car_details <- read_excel("D:/Data-Set/CAR DETAILS FROM CAR DEKHO.xlsx") 
View(car_details)

# Loading dataset
car_details

ggplot(data = car_details) + geom_point(mapping = aes(x = year, y = selling_price))

#linetype
ggplot(data = car_details) + 
  geom_smooth(mapping = aes(x = year, y = selling_price, linetype = fuel))

#To display different aesthetics in different layers
ggplot(data = car_details, mapping = aes(x = year, y = selling_price)) + 
  geom_point(mapping = aes(color = fuel)) + 
  geom_smooth()
