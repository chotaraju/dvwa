# Loading required libraries 
library(tidyverse)
library(readxl)

# Adding Datasets 
library(readxl) 
Olympic_medals <- read_excel("D:/Data-Set/Summer-Olympic-medals-1976-to-2008.xlsx")
View(Olympic_medals)

# Loading dataset
Olympic_medals

#plot using stat_count 
ggplot(data = Olympic_medals) + stat_count(mapping = aes(x = Medal))