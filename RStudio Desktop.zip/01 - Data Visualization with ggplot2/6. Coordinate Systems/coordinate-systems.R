# Loading required libraries 
library(tidyverse)
library(readxl)

# Adding Datasets 
library(readxl) 
Olympic_medals <- read_excel("D:/Data-Set/Summer-Olympic-medals-1976-to-2008.xlsx")
View(Olympic_medals)

# Loading dataset
Olympic_medals

# Plotting a simple boxplot
ggplot(data = Olympic_medals, mapping = aes(x = Year, y = Medal)) + 
  geom_boxplot()

# plotting a bar plot
bar <- ggplot(data = Olympic_medals) + 
  geom_bar( 
    mapping = aes(x = Gender, fill = Gender), 
    show.legend = FALSE, 
    width = 1
  ) + 
  theme(aspect.ratio = 1) + 
  labs(x = NULL, y = NULL) 

# applying coord_flip()
bar + coord_flip()

# applying coord_polar()
bar + coord_polar()