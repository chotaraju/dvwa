##loading datsets
library(tidyverse)

##loading dataset
Consumer_Price <- read_excel("D:/Data-Set/All India Consumer Price Index (RuralUrban) upto October 2022.xls", col_types = c("text", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric"))
View(Consumer_Price)

##Patterns and Models
ggplot(data = Consumer_Price) + geom_point(mapping = aes(x = Vegetables, y = Year))

#model to remove the very strong relationship between price and carat so we can explore the subtleties that remain
library(modelr)

mod <- lm(log(price) ~ log(carat), data = diamonds)

diamonds2 <- diamonds %>%
  add_residuals(mod) %>%
  mutate(resid = exp(resid))

ggplot(data = diamonds2) +
  geom_point(mapping = aes(x = carat, y = resid))

#relationship between cut and price—relative to their size, better quality diamonds are more expensive:
ggplot(data = diamonds2) +
  geom_boxplot(mapping = aes(x = cut, y = resid))

