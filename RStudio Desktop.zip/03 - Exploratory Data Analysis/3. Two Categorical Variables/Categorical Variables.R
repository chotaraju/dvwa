##loading datsets
library(tidyverse)
library(readxl)
Olympic <- read_excel("D:/Data-Set/Summer-Olympic-medals-1976-to-2008.xlsx")
View(Olympic)

#Two Categorical Variables
ggplot(data = Olympic) + geom_count(mapping = aes(x = Medal, y = Gender))

#to compute the count with dplyr
Olympic %>% count(Medal, Country)

#visualize with geom_tile() and the fill aesthetic:
Olympic %>% count(Medal, Year) %>% ggplot(mapping = aes(x = Medal, y = Year)) + geom_tile(mapping = aes(fill = n))

