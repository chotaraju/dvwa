##loading datsets
library(tidyverse)
library(readxl)
Olympic <- read_excel("D:/Data-Set/Summer-Olympic-medals-1976-to-2008.xlsx")
View(Olympic)

Consumer_Price <- read_excel("D:/Data-Set/All India Consumer Price Index (RuralUrban) upto October 2022.xls", col_types = c("text", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric"))
View(Consumer_Price)

##Two Continuous Variables
ggplot(data = Olympic) + geom_point(mapping = aes(x = Medal, y = Gender))

# using the alpha aesthetic to add transparency
ggplot(data = Consumer_Price) +
  geom_point(
    mapping = aes(x = Milk, y = Year),
    alpha = 1 / 100
  )
