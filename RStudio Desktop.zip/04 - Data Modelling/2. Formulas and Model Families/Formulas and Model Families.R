##loading libraries
library(tidyverse)
library(modelr)
options(na.action = na.warn)

df <- tribble(
  ~y, ~x1, ~x2,
  4, 2, 5,
  5, 1, 6
)

model_matrix(df, y ~ x1)

#subtract
model_matrix(df, y ~ x1 - 1)

#add
model_matrix(df, y ~ x1 + x2)
