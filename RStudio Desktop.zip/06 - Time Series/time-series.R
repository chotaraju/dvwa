##Load the Forecast Package into RStudio
#install.packages('forecast')
library(forecast)
data("AirPassengers")
class(AirPassengers)

##Display
AirPassengers


#check on our date values
start(AirPassengers)

end(AirPassengers)


##Missing Values
sum(is.na(AirPassengers))


##Summary
summary(AirPassengers)

plot(AirPassengers)


tsdata <- ts(AirPassengers, frequency = 12) 
ddata <- decompose(tsdata, "multiplicative")
plot(ddata)

##Plot the Different Components
plot(ddata$trend)
plot(ddata$seasonal)
plot(ddata$random)


##Trendline
plot(AirPassengers)
abline(reg=lm(AirPassengers~time(AirPassengers)))


##Box Plot
boxplot(AirPassengers~cycle(AirPassengers, xlab="Date", 
                            ylab = "Passenger Numbers (1000's)", 
                            main = "Monthly air passengers boxplot from 1949-1960"))

