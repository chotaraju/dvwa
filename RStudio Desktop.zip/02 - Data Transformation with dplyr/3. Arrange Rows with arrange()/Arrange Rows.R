# Loading required libraries
library(tidyverse)

# Adding Datasets 
library(readxl)
Consumer_Price <- read_excel("D:/Data-Set/All India Consumer Price Index (RuralUrban) upto October 2022.xls", 
                             col_types = c("text", "numeric", "numeric", "numeric", "numeric", "numeric", 
                                           "numeric", "numeric", "numeric", "numeric", "numeric", "numeric"))
View(Consumer_Price)

#it changes their order
arrange(Consumer_Price, Education, Housing, Health)

#reorder by a column in descending order
arrange(Consumer_Price, desc(Milk))

#sorting Missing values
df <- tibble(x = c(5, 2, NA))
arrange(df, x)

arrange(df, desc(x))
