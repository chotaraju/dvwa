# Loading required libraries
library(tidyverse)
library(nycflights13)

# Adding Datasets 
library(readxl)
Consumer_Price <- read_excel("D:/Data-Set/All India Consumer Price Index (RuralUrban) upto October 2022.xls", 
                             col_types = c("text", "numeric", "numeric", "numeric", "numeric", "numeric", 
                                           "numeric", "numeric", "numeric", "numeric", "numeric", "numeric"))
View(Consumer_Price)

#collapses a data frame to a single row
summarize(Consumer_Price, average = mean(Housing, na.rm = TRUE))

#to get average per month
by_education <- group_by(Consumer_Price, Sector, Year, Month)
summarize(by_education, Edu_average = mean(Education, na.rm = TRUE))

#relationship between the distance and average delay for each location.
delays <- flights %>%
  group_by(dest) %>%
  summarize(
    count = n(),
    dist = mean(distance, na.rm = TRUE),
    delay = mean(arr_delay, na.rm = TRUE)
  ) %>%
  filter(count > 20, dest != "HNL")
view(delays)

ggplot(data = delays, mapping = aes(x = dist, y = delay)) +
 geom_point(aes(size = count), alpha = 1/3) +
 geom_smooth(se = FALSE)
