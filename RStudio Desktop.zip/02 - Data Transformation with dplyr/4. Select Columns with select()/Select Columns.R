# Loading required libraries
library(tidyverse)

# Adding Datasets 
library(readxl)
Consumer_Price <- read_excel("D:/Data-Set/All India Consumer Price Index (RuralUrban) upto October 2022.xls", 
                             col_types = c("text", "numeric", "numeric", "numeric", "numeric", "numeric", 
                                           "numeric", "numeric", "numeric", "numeric", "numeric", "numeric"))
View(Consumer_Price)

##Select Columns with select()

#to select clothing, housing and health column
select(Consumer_Price, Clothing, Housing, Health)

#Select all columns between Milk and Spices (inclusive)
select(Consumer_Price, Milk:Spices)

#Select all columns except those from year to day (inclusive)
select(Consumer_Price, -(Milk:Spices))

#rename() that keeps all the variables that aren’t explicitly mentioned
rename(Consumer_Price, Footwears = Footwear)

#to move education and housing to the start of the data frame
select(Consumer_Price, Education, Housing, everything())

