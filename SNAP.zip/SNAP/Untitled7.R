# Displaying Bipartite network in the graph Format.

install.packages("igraph")
library(igraph)


# Read the data file
davis <- read.csv(file.choose(), header=FALSE)
g <- graph.data.frame(davis, directed=FALSE)
plot(g)


# Perform bipartite mapping
bipartite.mapping(g)

# Assign the 'type' attribute based on bipartite mapping
V(g)$type <- bipartite_mapping(g)$type

#Plotting a bipartite network
plot(g)


# Plot the bipartite network with adjusted vertex labels, colors, and shapes
plot(g, vertex.label.cex = 0.8, vertex.label.color = "black") 
V(g)$color <- ifelse(V(g)$type, "lightblue", "salmon")
V(g)$shape <- ifelse(V(g)$type, "circle", "square")
E(g)$color <- "lightgray"
plot(g, vertex.label.cex = 0.8, vertex.label.color = "black") 


# Further customization of vertex labels
V(g)$label.color <- "black" 
#label.cex value to adjust our label size
V(g)$label.cex <- 1 
V(g)$frame.color <-  "gray"
V(g)$size <- 18 

# Plot the graph with a specified layout algorithm
plot(g, layout = layout_with_graphopt)


# Plot the bipartite graph with specified layout and vertex size
plot(g, layout=layout.bipartite, vertex.size=7, vertex.label.cex=0.6)
