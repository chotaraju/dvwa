#(I)  View data collection forms and/or import one-mode/ two-mode datasets
#(II) Basic Networks matrices transformations

install.packages("igraph")
library(igraph)

# Read nodes data from CSV file
nodes <-read.csv("netscix2016/Dataset1-Media-Example-NODES.csv", header=T, as.is=T)
head(nodes)

# Read edges data from CSV file
links <- read.csv("netscix2016/Dataset1-Media-Example-EDGES.csv", header=T, as.is=T)
head(links)


# graph from the node and edge data
net <- graph.data.frame(d=links, vertices=nodes, directed=T)

# adjacency matrix of the graph
get.adjacency(net)


# Plot the graph
plot(net)
