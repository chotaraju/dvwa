#Compute the following node level measures:
#(i) Density; (ii) Degree; (iii) Reciprocity; (iv) Transitivity; (v) Centralization; (vi) Clustering

install.packages("igraph")
library(igraph)

# Read node and edge data
nodes <- read.csv("netscix2016/Dataset1-Media-Example-NODES.csv", header = TRUE, as.is = TRUE)
edges <- read.csv("netscix2016/Dataset1-Media-Example-EDGES.csv", header = TRUE, as.is = TRUE)

# Display the first few rows of node and edge data
head(nodes)
head(edges)

# Create a graph from the data
g <- graph.data.frame(d = edges, directed = TRUE, vertices = nodes)

# Plot the graph
plot(g)

# (1) Density
vcount(g)  # Number of vertices
ecount(g)  # Number of edges
density <- ecount(g) / (vcount(g) * (vcount(g) - 1))  # Calculate density
density


# (2) Degree
degree(g)  # Degree of each vertex


# (3) Reciprocity
dg <- graph.formula(1-+2, 1-+3, 2++3)  # Create a directed graph
plot(dg)
reciprocity(dg)  # Reciprocity
dyad_census <- dyad.census(dg)  # Dyad census
2 * dyad_census$mut / ecount(dg)  # Calculate reciprocity



# (4) Transitivity
kite <- graph.famous("Krackhardt_Kite")  # Load Krackhardt Kite graph
atri <- adjacent.triangles(kite)  # Get adjacent triangles
plot(kite, vertex.label = atri)
transitivity(kite, type = "local")  # Local transitivity
adjacent.triangles(kite) / (degree(kite) * (degree(kite) - 1) / 2)  # Calculate transitivity



# (5) Centralization

# Degree Centrality
centralization.degree(g, mode = "in", normalized = TRUE)  # Calculate degree centrality


# Closeness Centrality
closeness <- closeness(g, mode = "all", weights = NA)  # Calculate closeness centrality
centralization.closeness(g, mode = "all", normalized = TRUE)  # Calculate closeness centrality centralization


# Betweenness Centrality
betweenness <- betweenness(g, directed = TRUE, weights = NA)  # Calculate betweenness centrality
centralization.betweenness(g, directed = TRUE, normalized = TRUE)  # Calculate betweenness centrality centralization
edge.betweenness(g, directed = TRUE, weights = NA)  # Calculate edge betweenness centrality


# Eigenvector Centrality
centralization.evcent(g, directed = TRUE, normalized = TRUE)  # Calculate eigenvector centrality centralization


# (6) Clustering
g2 <- barabasi.game(50, p = 2, directed = FALSE)  # Create a Barabási-Albert network
g1 <- watts.strogatz.game(1, size = 100, nei = 5, p = 0.05)  # Create a Watts-Strogatz network
g <- graph.union(g1, g2)  # Combine the two networks
g <- simplify(g)  # Simplify the graph
ebc <- edge.betweenness.community(g, directed = FALSE)  # Detect communities using edge betweenness

# Modularities
mods <- sapply(0:ecount(g), function(i) {  
  g2 <- delete_edges(g, ebc$removed.edges[seq(length = 1)])  # Delete edges
  cl <- clusters(g2)$membership  # Get membership of clusters
})
plot(mods, pch = 20)  # Plot modularities


# Delete edges
g2 <- delete.edges(g, ebc$removed.edges[seq(length = which.max(mods) - 1)])  
V(g)$color <- clusters(g2)$membership  # Set vertex colors based on community membership
g$layout <- layout.fruchterman.reingold(g)  # Set layout
plot(g, vertex.label = NA)  # Plot the graph without vertex labels

plot(kite)  # Plot Krackhardt Kite graph

get.adjedgelist(kite, mode = c("all", "out", "in", "total"))  # Get adjacency edge list

fc <- fastgreedy.community(g2)  # Detect communities using Fast Greedy algorithm
com <- cutat(fc, steps = which.max(fc$modularity))  # Cut the dendrogram
V(g2)$color <- fc$membership + 1  # Set vertex colors based on community membership
g2$layout <- layout.fruchterman.reingold  # Set layout
plot(g2, vertex.label = NA)  # Plot the graph without vertex labels