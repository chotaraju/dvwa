getwd()

install.packages('tm')
install.packages('topicmodels')

# Load the necessary libraries
library(topicmodels)
library(tm)

# set the working directory folder of the dataset
setwd("british-fiction-corpus")

# load all the text files in the dataset
filename<-list.files(path=".",pattern="*.txt")
filetext<-lapply(filename,readLines)

# Create a corpus from the dataset
myCorpus<-Corpus(VectorSource(filetext))

# Create a custom stopwords dictionary
custom_stopwords <- c("the", "and", "in", "is", "it", "for", "this", "that")  

# Preprocess the text data
myCorpus <- tm_map(myCorpus, content_transformer(tolower))  # Convert to lowercase
myCorpus <- tm_map(myCorpus, removePunctuation)  # Remove punctuation
myCorpus <- tm_map(myCorpus, removeNumbers)  # Remove numbers
myCorpus <- tm_map(myCorpus, removeWords, stopwords("en"))  # Remove common English stopwords
myCorpus <- tm_map(myCorpus, removeWords, custom_stopwords)  # Remove custom stopwords
myCorpus <- tm_map(myCorpus, stripWhitespace)  # Remove extra white spaces


# Create a document-term matrix
dtm<-DocumentTermMatrix(myCorpus)
dtm

# Fit the LDA model
num_topics <- 3  # You can choose the number of topics you want
lda_model <- LDA(dtm, k = num_topics)

# Explore topics
topics <- terms(lda_model, 10)  # Get the top 10 terms for each topic

# Print the top terms in each topic
topics

# Create a bar plot to visualize the top terms in each topic
library(ggplot2)

topic_terms_df <- data.frame(
  Topic = rep(1:num_topics, each = 10),
  Term = unlist(topics),
  Frequency = rep(1:10, times = num_topics)
)

Term = unlist(topics)
ggplot(topic_terms_df, aes(x = reorder(Term, -Frequency), y = Frequency, 
                           fill = factor(Topic))) + geom_bar(stat = "identity") +
  labs(title = "Top Terms in Each Topic", x = "Term", y = "Frequency") +
  theme_minimal() + facet_wrap(~Topic, scales = "free") +
  coord_flip() + scale_fill_brewer(palette = "Set1")

