# function to read a text file and generate K-shingles
readInteger <- function() {
  # take k from user
  n <- readline(prompt = "enter value of k-1: ")
  k <- as.integer(n)
  
  # read text file
  u1 <- readLines("Data.txt")
  
  # start k with 0 and counter var i
  Shingle <- 0
  i <- 0
  
  # loop to generate K-shingles from the text
  while (i < nchar(u1) - k + 1) {
    # remove K-shingle of length 'k' from the text
    Shingle[i] <- substr(u1, start = i, stop = i + k)
    
    # K-shingle
    print(Shingle[i])
    
    # Increment the counter
    i <- i + 1
  }
}
