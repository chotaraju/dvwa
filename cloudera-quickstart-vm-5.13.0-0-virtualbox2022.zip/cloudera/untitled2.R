data("iris")
names(iris)

#Create subset of data
new_data <- subset(iris, select = c(-Species))
new_data

############################cluster plot k-means clustering with WCSS
cl <- kmeans(new_data,3)
cl

#Calculating WCSS
data <- new_data
wss <- sapply(1:15, function(k){kmeans(data, k)$tot.withinss})
wss

#plot graph of WCSS val vs no of cluster
plot(1:15, wss, type="b", pch=19, frame=FALSE, xlab = "No of clusters in K",
     ylab = "Total within-clusters sum of squares")


############################hierarchical clustering dendogram
#installing packages
install.packages("cluster")
library(cluster)

clusplot(new_data, cl$cluster, color=TRUE, shade=TRUE, label=2, lines=0)

cl$cluster
cl$centers

clusters <- hclust(dist(iris[, 3:4]))
plot(clusters)

clusterCut <- cutree(clusters, 3)
table(clusterCut, iris$Species)

#scatter plot
library(ggplot2)
ggplot(iris, aes(Petal.Length, Petal.Width, color=iris$Species)) +
  geom_point(alpha = 0.4, size = 3.5) + geom_point(col = clusterCut) +
  scale_color_manual(values = c('black','red','green'))



############################DBSCAN
install.packages("fpc")
library(fpc)

iris_1 <- iris[-5]
set.seed(220)
Dbscan_cl <- dbscan(iris_1, eps=0.45, MinPts=5)
Dbscan_cl$cluster

table(Dbscan_cl$cluster, iris$Species)

plot(Dbscan_cl, iris_1, main = "DBScan")

plot(Dbscan_cl, iris_1, main = "Petal width vs Sepal length")




