library(textreuse)

# Generate a MinHash function with 240 hash functions
minhash <- minhash_generator(n = 240, seed = 3552)

head(minhash(c("turn tokens into", "tokens into hashes", "into hashes fast")))

dir <- system.file("extdata/ats", package = "textreuse")

corpus <- TextReuseCorpus(dir = dir, 
                          tokenizer = tokenize_ngrams,   
                          n = 5,                         
                          minhash_func = minhash,        
                          keep_tokens = TRUE,            
                          progress = FALSE)             

# MinHash signature
head(minhashes(corpus[[1]]))

# Locality-Sensitive Hashing (LSH)
buckets <- lsh(corpus, bands = 80, progress = FALSE)
buckets

# Identify candidate pairs of similar documents using LSH
candidates <- lsh_candidates(buckets)

# Display the candidate pairs
candidates

# Compare the candidate pairs and calculate Jaccard similarity
lsh_compare(candidates, corpus, jaccard_similarity, progress = FALSE)
