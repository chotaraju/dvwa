############################Mean & Median
library(readxl)

zomato <- read_excel("zomato.xlsx")

head(zomato)

mean(zomato$`avg cost (two people)`)

mean(zomato$`rate (out of 5)`, na.rm = TRUE)

New_df = zomato

New_df$`rate (out of 5)` = ifelse(is.na(New_df$`rate (out of 5)`),
                                  median(New_df$`rate (out of 5)`,
                                         na.rm = TRUE),
                                  New_df$`rate (out of 5)`)
head(New_df)



############################Handling Missing Values
dt=read_excel(file.choose())
head(dt)

dt$marks = ifelse(is.na(dt$marks),
                  mean(dt$marks,
                       na.rm = TRUE),
                  dt$marks)

View(dt)



############################Removing Outliers using boxplot
data <- iris[,2]
length(data)

boxplot(data)
boxplot(data, plot = FALSE)$out

outliers <- boxplot(data, plot = FALSE)$out

data_no_outlier <- data[-which(data %in% outliers)]

boxplot(data_no_outlier, plot = FALSE)$out

length(data_no_outlier)

boxplot(data_no_outlier)



############################CORRELATION, CHI-SQUARE, BAR CHART, SCATTER & BOX PLOT
library(ggplot2)
library(plotly)
library(readxl)

titanic <- read_excel("titanic.xlsx")
my_data <- titanic
summary(my_data)


############################Correlation
cor_matrix <- cor(my_data[, c("Age", "Fare")], use = "pairwise.complete.obs")
print(cor_matrix)


############################Chi-square
chisq_result <- chisq.test(my_data$Pclass, my_data$Survived)
print(chisq_result)


############################Scatter plot
scatter_plot <- ggplot(my_data, aes(x = Age, y = Fare)) + geom_point()
print(scatter_plot)


############################Bar chart
bar_chart <- ggplot(my_data, aes(x = Pclass, fill = factor(Survived))) + 
  geom_bar(position = "dodge") + 
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
print(bar_chart)


############################Box plot
box_plot <- ggplot(my_data, aes(x = factor(Pclass), y = Fare, fill = factor(Survived))) + 
  geom_boxplot() + theme(axis.text.x = element_text(angle = 45, hjust = 1))
print(box_plot)



############################DECISION TREE MODEL,PRUNED DECISION TREE MODEL
#Installing Packages
install.packages("partykit")
install.packages("caret")
install.packages("pROC")
install.packages('rattle')
install.packages('rpart.plot')
install.packages('RColorBrewer')

library(readxl)
titanic <- read_excel("titanic.xlsx")
View(titanic)
summary(titanic)
names(titanic)

library(partykit)
titanic$Survived<-as.factor(titanic$Survived)#convert to categorical
summary(titanic$Survived)
names(titanic)

set.seed(1234)
pd<-sample(2,nrow(titanic),replace = TRUE, prob=c(0.8,0.2))
trainingset<-titanic[pd==1,]#first partition
validationset<-titanic[pd==2,]#second partition
class(titanic$PassengerId)
class(titanic$Survived)
class(titanic$Sex)
class(titanic$Pclass)
class(titanic$Name)
class(titanic$Age)
class(titanic$SibSp)
class(titanic$Parch)
class(titanic$Ticket)
class(titanic$Fare)
class(titanic$Cabin)
class(titanic$Embarked)


############################Simple Decision Tree Model
tree<-ctree(formula = Survived ~ Pclass + Age + SibSp + Parch + Fare ,data=trainingset)
class(titanic$Survived)
plot(tree)


############################Prunning - pruned decision tree model
tree<-ctree(formula = Survived ~ Pclass + Age + SibSp + Parch +
              Fare ,data=trainingset,control=ctree_control(mincriterion = 0.99,minsplit = 500))
plot(tree)

#predictions from the pruned decision tree model
pred<-predict(tree,validationset,type="prob")
pred
pred<-predict(tree,validationset)
pred

#evaluate performance of the pruned decision tree model
library(caret)
confusionMatrix(pred,validationset$Survived)
pred<-predict(tree,validationset,type="prob")
pred

#ROC Curve of the pruned decision tree model
library(pROC)
plot(roc(validationset$Survived,pred[ ,2]))