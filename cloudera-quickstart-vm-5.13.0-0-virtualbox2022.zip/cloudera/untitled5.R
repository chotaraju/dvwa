install.packages('arules')
install.packages('arules Viz')
install.packages("RColorBrewer")

library(arules)
library(arulesViz)
library(RColorBrewer)


##########################################GROCERIES

# Load the "Groceries" dataset
data("Groceries")

# Inspect the structure of the dataset
str(Groceries)

# Display the first two rows of the dataset for understanding its format
inspect(head(Groceries, 2))

# Access item labels from the dataset
Groceries@itemInfo$labels

# Perform association rule mining using the Apriori algorithm
grocery_rules <- apriori(Groceries, parameter = list(supp = 0.01, conf = 0.2))

# Display the first 10 generated association rules
inspect(grocery_rules[1:10])

# Display the top 3 association rules with the highest confidence
inspect(head(sort(grocery_rules, by = "confidence"), 3))

# Display the bottom 3 association rules with the lowest confidence
inspect(tail(sort(grocery_rules, by = "confidence"), 3))

# Create association rules specifically related to "whole milk"
wholemilk_rules <- apriori(data = Groceries, parameter = list(supp = 0.001, conf = 0.08), 
                           appearance = list(rhs = "whole milk"))

# Display the top 3 association rules with the highest confidence for "whole milk"
inspect(head(sort(wholemilk_rules, by = "confidence"), 3))

# Generate association rules for groceries with increased support and confidence thresholds
grocery_rules_increased_support <- apriori(Groceries, parameter = list(support = 0.02, 
                                                                       confidence = 0.5))

# Display the top 3 association rules with the highest confidence for increased support
inspect(head(sort(grocery_rules_increased_support, by = "confidence"), 3))

# Generate an item frequency plot showing the absolute frequency of the top 20 items in the dataset
itemFrequencyPlot(Groceries, topN = 20, type = "absolute", 
                  col = brewer.pal(8, 'Pastel2'), 
                  main = "Absolute Item Frequency Plot")




##########################################RESTAURANT

# Read and preprocess the restaurant order data
txn <- read.transactions(file = "restaurant-1-orders.csv",
                         rm.duplicates = TRUE,
                         format = "single",
                         sep = ",",
                         header = TRUE,
                         cols = c("Order Number", "Item Name"))

# Inspect the structure of the transaction data
str(txn)

# Display the first two rows of the transaction data for understanding
inspect(head(txn, 2))

# Access item labels from the dataset
txn@itemInfo$labels

# Perform association rule mining using the Apriori algorithm
rules <- apriori(txn, parameter = list(supp = 0.01, conf = 0.2))

# Display the first 10 generated association rules
inspect(rules[1:10])

# Display the top 3 association rules with the highest confidence
inspect(head(sort(rules, by = "confidence"), 3))

# Generate an item frequency plot to visualize item frequencies
itemFrequencyPlot(txn, topN = 20, type = "absolute", col = brewer.pal(8, 'Pastel2'), 
                  main = "Absolute Item Frequency Plot")

# Create association rules specifically related to "Pilau Rice"
Pilau_Rice_rules <- apriori(data = txn, parameter = list(supp = 0.003, conf = 0.08), 
                            appearance = list(rhs = "Pilau Rice"))

# Display the top 3 association rules with the highest confidence for "Pilau Rice"
inspect(head(sort(Pilau_Rice_rules, by = "confidence"), 3))

# Generate association rules for the transaction data with increased support and confidence
rules_increased_support <- apriori(txn, parameter = list(support = 0.02, confidence = 0.5))

# Display the top 3 association rules with the highest confidence for increased support
inspect(head(sort(rules_increased_support, by = "confidence"), 3))



##########################################COFFEE LISTING FROM WALMART
# Load necessary libraries for association rule mining and data visualization
library(arules)
library(arulesViz)
library(RColorBrewer)

# Read the dataset of coffee listings from Walmart
data <- read.transactions("coffee-listings-from-all-walmart-stores.csv", 
                          rm.duplicates = TRUE, 
                          format = "single", 
                          sep = ",", 
                          header = TRUE, 
                          cols = c("seller_name", "coffee_type"))

# Inspect the structure of the transaction data
str(data)

# Display the first few rows of the transaction data
inspect(head(data))

# Access item labels
data@itemInfo$labels

# Perform association rule mining using the Apriori algorithm with specified support and confidence thresholds
data_rules <- apriori(data, parameter = list(supp = 0.01, conf = 0.2))

# Display the generated association rules
data_rules

# Inspect the first 20 association rules
inspect(data_rules[1:20])

# Inspect the top 10 association rules with the highest confidence
inspect(head(sort(data_rules, by = "confidence"), 10))

# Inspect the bottom 10 association rules with the lowest confidence
inspect(tail(sort(data_rules, by = "confidence"), 10))

# Create association rules specifically related to "instant coffee"
instant_coffee_rules <- apriori(data = data, parameter = list(supp = 0.001, conf = 0.08), 
                                appearance = list(rhs = "instant coffee"))

# Display the top 10 association rules with the highest confidence for "instant coffee"
inspect(head(sort(instant_coffee_rules, by = "confidence"), 10))

# Create association rules for "instant coffee" with increased support and confidence thresholds
instant_coffee_rules_increased_support <- apriori(data, parameter = list(support = 0.01, confidence = 0.5))

# Display the top 10 association rules with the highest confidence for "instant coffee" 
#with increased support
inspect(head(sort(instant_coffee_rules_increased_support, by = "confidence"), 10))

# Generate an item frequency plot showing the absolute frequency of the top 20 items in the dataset
itemFrequencyPlot(data, topN = 20, type = "absolute", col = brewer.pal(8, 'Pastel2'), 
                  main = "Absolute Item Frequency Plot")
