# dictionary to represent web pages and their connections.
vect_dict = {"A": [0, 1, 1, 0], "B": [0, 0, 0, 0], "C": [0, 1, 0, 1], "D": [1, 0, 0, 0]}
print("The web pages A, B, C and their connections.", vect_dict)

# damping factor.
df = 0.85
print("df is", df)

# set with a initail value
PageRank = {"A": 1, "B": 1, "C": 1, "D": 1}
print("The page rank is:", PageRank)

# page name to their column indices
columns = {"A": 0, "B": 1, "C": 2, "D": 3}
print("The columns are:", columns)

# incoming connections to page.
def connections(page):
    column = columns[page]
    incomings = []
    for i in vect_dict.keys():
        for connections in range(len(vect_dict[i])):
            if connections == column and vect_dict[i][connections] == 1:
                incomings.append(i)
    return incomings

# number of outgoing links from that page
def outDegree(node):
    count = 0
    for i in vect_dict[node]:
        if i == 1:
            count += 1
    return count

# calculate PageRank.
for iteration in range(6):
    for i in PageRank.keys():
        factor = 0
        incoming_nodes = connections(i)
        for node in incoming_nodes:
            factor = factor + PageRank[node] / outDegree(node)
        PageRank[i] = (1 - df) + df * factor

    # PageRank values of each iteration.
    print("Iteration", iteration, ":", PageRank)
