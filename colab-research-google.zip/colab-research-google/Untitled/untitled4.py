# **N-gram model**

import nltk

nltk.download('punkt')

from textblob import TextBlob

sentence = "Technology is best when it brings people together";

ngram_object = TextBlob(sentence)

bigrams=ngram_object.ngrams (n=2) # Computing Bigrams
print(bigrams)

trigrams=ngram_object.ngrams (n=3) # Computing Trigrams
print(trigrams)

